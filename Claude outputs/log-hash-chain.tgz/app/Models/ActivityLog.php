<?php

namespace App\Models;

use App\Support\AuditChain;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class ActivityLog extends Model
{
    use HasFactory;

    protected $table = 'activity_logs';

    protected $fillable = [
        'user_code',
        'action',
        'module',
        'description',
    ];   // the time and the IP address are written by the system only, never from a request

    // IMPORTANT: ensure timestamps are enabled
    public $timestamps = true;

    /** The chain fingerprints are for verification only; they never leave the server in a response. */
    protected $hidden = ['prev_hash', 'row_hash'];

    private static ?bool $chained = null;

    /**
     * Screen filter name => the module name stored in the log. One list, used by the
     * on-screen log and by its printed / exported report, so they always agree.
     */
    public const MODULE_FILTERS = [
        'event'        => 'Events',
        'resident'     => 'User',
        'membership'   => 'Membership',
        'notification' => 'Notifications',
        'scan'         => 'QR',
        'system'       => 'Authentication',
        'inventory'    => 'Inventory',
        'budget'       => 'Budget',
        'household'    => 'Households',
        'profiling'    => 'Profiling Settings',
        'archive'      => 'Archive',
        'report'       => 'Reports',
    ];

    /**
     * A new row joins the hash chain (App\Support\AuditChain): it stores the fingerprint of the row
     * before it and its own. The read of the previous row and the insert happen in one transaction
     * with the previous row locked, so two actions at the same moment cannot both follow the same row.
     */
    protected function performInsert(Builder $query)
    {
        self::$chained ??= Schema::hasColumn($this->getTable(), 'row_hash');
        if (!self::$chained) {
            return parent::performInsert($query);   // the chain columns have not been added yet (migration not run)
        }

        return DB::transaction(function () use ($query) {
            if ($this->ip_address === null && app()->bound('request')) {
                $this->ip_address = request()->ip();
            }
            $this->updateTimestamps();   // the time is part of the fingerprint, so it is fixed before it is calculated

            $last = DB::table($this->getTable())->orderByDesc('id')->lockForUpdate()->first(['row_hash']);
            $previous = $last->row_hash ?? null;

            $this->setAttribute('prev_hash', $previous ?? '');
            $this->setAttribute('row_hash', AuditChain::fingerprint($previous, $this->getAttributes()));

            return parent::performInsert($query);
        });
    }

    protected static function booted(): void
    {
        // Every new log row remembers the device it came from, wherever it is written
        // (controllers, services, ...). Console / queue work has no request, so stays empty.
        static::creating(function (self $log) {
            if ($log->ip_address === null && app()->bound('request')) {
                $log->ip_address = request()->ip();
            }
        });
    }

    /**
     * The one set of filters for the activity log: free-text search (LIKE wildcards typed by
     * the user are matched literally), module, a single day (Manila time) and a day range.
     *
     * @param  array{search?:?string,type?:?string,date?:?string,date_from?:?string,date_to?:?string}  $f
     */
    public function scopeFiltered(Builder $query, array $f): Builder
    {
        $search = trim((string) ($f['search'] ?? ''));
        if ($search !== '') {
            $like = '%' . addcslashes(mb_substr($search, 0, 100), '\\%_') . '%';
            // MySQL reads the backslash as the escape character by default; SQLite must be told.
            $esc = $query->getConnection()->getDriverName() === 'sqlite' ? " ESCAPE '\\'" : '';
            $query->where(function ($q) use ($like, $esc) {
                foreach (['user_code', 'action', 'module', 'description'] as $i => $column) {
                    $q->{$i === 0 ? 'whereRaw' : 'orWhereRaw'}("{$column} LIKE ?{$esc}", [$like]);
                }
            });
        }

        $type = $f['type'] ?? null;
        if ($type && $type !== 'all' && isset(self::MODULE_FILTERS[$type])) {
            // Older rows were saved under module 'Residents'; keep them in the Residents filter.
            $query->whereIn('module', $type === 'resident' ? ['User', 'Residents'] : [self::MODULE_FILTERS[$type]]);
        }

        // One chosen day, or a from/to range. A day runs from 00:00:00 up to, but NOT including,
        // 00:00:00 of the next day, so a row stamped exactly at midnight belongs to one day only.
        if (!empty($f['date'])) {
            $day = self::parseDay($f['date']);
            if ($day) {
                $query->where('created_at', '>=', $day)->where('created_at', '<', $day->copy()->addDay());
            }
        } else {
            $from = !empty($f['date_from']) ? self::parseDay($f['date_from']) : null;
            $to = !empty($f['date_to']) ? self::parseDay($f['date_to']) : null;
            if ($from) {
                $query->where('created_at', '>=', $from);
            }
            if ($to) {
                $query->where('created_at', '<', $to->copy()->addDay());
            }
        }

        return $query;
    }

    private static function parseDay(string $value): ?Carbon
    {
        try {
            return Carbon::parse($value, 'Asia/Manila')->startOfDay();
        } catch (\Throwable) {
            return null;
        }
    }
}
