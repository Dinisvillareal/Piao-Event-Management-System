<?php

namespace App\Console\Commands;

use App\Support\AuditChain;
use Illuminate\Console\Command;

/**
 * Checks the activity log for tampering (see App\Support\AuditChain).
 *
 *   php artisan log:verify            walks the log and names the first rows that were edited, removed or added by hand
 *   php artisan log:verify --anchor   when the log is intact, also saves a checkpoint (the newest row), so that
 *                                     rows later cut off the end of the log are caught as well
 *
 * It only reads; it changes nothing except the checkpoint file when asked to.
 */
class LogVerify extends Command
{
    protected $signature = 'log:verify {--anchor : Save the newest row as a checkpoint when the log is intact}';

    protected $description = 'Check the activity log for edited, removed or hand-added rows';

    public function handle(): int
    {
        $r = AuditChain::check();

        $this->line("Rows in the log:        {$r['rows']}");
        $this->line("Protected by the chain: {$r['chained']}");
        $this->line("Older, before the chain: {$r['unchained']}");
        if ($r['anchor']) {
            $this->line("Checkpoint:             row #{$r['anchor']['id']}, saved {$r['anchor']['saved_at']}");
        }

        if ($r['problems']) {
            $this->newLine();
            $this->error('TAMPERING DETECTED. The log does not match its fingerprints:');
            foreach (array_slice($r['problems'], 0, 25) as $p) {
                $this->line("  Row #{$p['id']} {$p['problem']}");
            }
            if (count($r['problems']) > 25) {
                $this->line('  ... and ' . (count($r['problems']) - 25) . ' more.');
            }

            return self::FAILURE;
        }

        $this->newLine();
        $this->info($r['chained'] ? 'The activity log is intact: every protected row matches its fingerprint and follows the one before it.' : 'No row is protected by the chain yet (new actions will be).');

        if ($this->option('anchor') && $r['head']) {
            file_put_contents(AuditChain::anchorPath(), json_encode(['id' => $r['head']['id'], 'hash' => $r['head']['hash'], 'saved_at' => now()->toDateTimeString()]));
            $this->line("Checkpoint saved at row #{$r['head']['id']}.");
        }

        return self::SUCCESS;
    }
}
