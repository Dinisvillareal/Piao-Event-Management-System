<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/**
 * Tamper evidence for the activity log (a hash chain).
 *
 * Each row stores a fingerprint of its own content together with the fingerprint of the row
 * before it. Editing a row changes its fingerprint; removing, adding or re-ordering rows breaks
 * the link to the next one. The fingerprint is an HMAC, so it also needs a secret key that is
 * kept outside the database (config/audit.php); a person with database access alone cannot
 * recalculate the chain after changing a row.
 *
 * Rows saved before the chain existed carry no fingerprint and are left alone. A checkpoint
 * (the newest row and its fingerprint, saved with `log:verify --anchor`) additionally catches
 * rows cut off the end of the log, which a chain by itself cannot show.
 */
class AuditChain
{
    /** The fields a fingerprint covers, in order. */
    public const FIELDS = ['user_code', 'action', 'module', 'description', 'ip_address', 'created_at'];

    public static function anchorPath(): string
    {
        return storage_path('app/audit-anchor.json');
    }

    public static function fingerprint(?string $previous, array $row): string
    {
        $payload = [(string) $previous];
        foreach (self::FIELDS as $field) {
            $value = $row[$field] ?? null;
            $payload[] = $value === null ? null : (string) $value;
        }

        $key = (string) (config('audit.key') ?: 'piao-connect-activity-log');

        return hash_hmac('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key);
    }

    /**
     * Walks the whole log, oldest first.
     *
     * @return array{rows:int, chained:int, unchained:int, problems:array<int,array{id:int,problem:string}>, head:?array{id:int,hash:string}, anchor:?array}
     */
    public static function check(): array
    {
        $problems = [];
        $rows = $chained = $unchained = 0;
        $started = false;
        $expected = '';
        $head = null;
        $ids = [];
        $anchor = is_file(self::anchorPath()) ? json_decode((string) file_get_contents(self::anchorPath()), true) : null;
        $anchorSeen = null;

        DB::table('activity_logs')->orderBy('id')->select(array_merge(['id', 'prev_hash', 'row_hash'], self::FIELDS))
            ->chunkById(1000, function ($chunk) use (&$problems, &$rows, &$chained, &$unchained, &$started, &$expected, &$head, $anchor, &$anchorSeen) {
                foreach ($chunk as $r) {
                    $rows++;

                    if ($r->row_hash === null) {
                        if ($started) {
                            $problems[] = ['id' => (int) $r->id, 'problem' => 'has no fingerprint but comes after fingerprinted rows (it was added outside the application)'];
                        } else {
                            $unchained++;
                        }
                        continue;
                    }

                    $started = true;
                    $chained++;

                    if ((string) $r->prev_hash !== $expected) {
                        $problems[] = ['id' => (int) $r->id, 'problem' => 'does not follow the row before it (a row in between was removed, added or changed)'];
                    }
                    if (!hash_equals(self::fingerprint($r->prev_hash, (array) $r), (string) $r->row_hash)) {
                        $problems[] = ['id' => (int) $r->id, 'problem' => 'was edited: its content no longer matches its fingerprint'];
                    }

                    $expected = (string) $r->row_hash;
                    $head = ['id' => (int) $r->id, 'hash' => (string) $r->row_hash];

                    if ($anchor && (int) $r->id === (int) ($anchor['id'] ?? 0)) {
                        $anchorSeen = (string) $r->row_hash;
                    }
                }
            });

        if ($anchor) {
            if ($anchorSeen === null) {
                $problems[] = ['id' => (int) $anchor['id'], 'problem' => 'is the saved checkpoint, but it is missing (rows were removed from the end of the log)'];
            } elseif (!hash_equals((string) $anchor['hash'], $anchorSeen)) {
                $problems[] = ['id' => (int) $anchor['id'], 'problem' => 'is the saved checkpoint, but its fingerprint has changed'];
            }
        }

        return compact('rows', 'chained', 'unchained', 'problems', 'head', 'anchor');
    }
}
