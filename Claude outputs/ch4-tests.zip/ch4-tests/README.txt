PiaoConnect – Chapter IV automated test pack
=============================================
1. Copy the "tests" folder into your project root (it adds tests/Support.php and
   tests/Feature/Ch4AuthSecurityTest.php + Ch4RecordsTest.php; nothing existing is overwritten).
2. Apply the one-line fix (see attendance-rollback-fix.patch): in
   app/Http/Controllers/EventAttendanceController.php, inside timeIn(), add
   DB::rollBack(); just before  return response()->json(['message' => 'Member already signed in.'], 400);
   (the first one, inside `if ($attendance->time_in) {`).
3. Run:   php artisan test --filter=Ch4
   (phpunit.xml uses SQLite in memory, so PHP needs the pdo_sqlite extension: in XAMPP
   php.ini enable  extension=pdo_sqlite  and  extension=sqlite3.)
4. Copy the real Pass/Fail result of each test into the "Test Cases" sheet of the workbook.

What my own run showed (copy of your code, SQLite, 40 tests): 38 passed, 2 not passed.
- tc46: the server accepts a NEW expense on a finished event (HTTP 201). Only the budget change is blocked.
  Decide: add a server-side check, or keep late receipts allowed and reword TC-46.
- tc55 (PDF export): not run in my copy because the Blade views were not included; run it on your machine.
Not covered by automation (do these by hand): QR display on a phone, notifications/SMS/Facebook, feedback,
print on different paper sizes, language switch, Word export, large-list timing.
