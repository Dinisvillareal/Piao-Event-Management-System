<?php

namespace Tests\Feature;

use App\Models\Event;
use App\Support\Uploads;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Tests\Support;
use Tests\TestCase;

/**
 * Attachments are locked to their file types at the database (migration
 * 2026_11_19_000004) and by the upload rules: photos and the validation ID are
 * JPG or PNG; expense receipts are JPG, PNG or one PDF.
 */
class UploadTypeLockTest extends TestCase
{
    use RefreshDatabase, Support;

    private const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
    private const GIF = 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

    /** A real file on disk (not the test fake, which trusts the name): its type is read from its content. */
    private function realFile(string $name, string $base64): UploadedFile
    {
        $tmp = tempnam(sys_get_temp_dir(), 'up');
        file_put_contents($tmp, base64_decode($base64));

        return new UploadedFile($tmp, $name, 'application/octet-stream', null, true);
    }

    private function migration(): object
    {
        return require database_path('migrations/2026_11_19_000004_lock_upload_file_types.php');
    }

    private static int $n = 0;

    private function eventId(): int
    {
        return DB::table('events')->insertGetId(['name' => 'E' . ++self::$n, 'description' => 'd', 'location' => 'Hall', 'event_start' => now()]);
    }

    /** Inserts one row that carries $value in $column of $table; returns its id. */
    private function row(string $table, string $column, $value): int
    {
        $n = ++self::$n;
        $row = match ($table) {
            'users'                         => ['user_code' => "PR-U{$n}", 'first_name' => "F{$n}", 'last_name' => "L{$n}", 'contact_number' => '09171234567', 'role' => 'Resident'],
            'inventory_items'               => ['name' => "Item {$n}"],
            'event_expenses'                => ['event_id' => $this->eventId(), 'item' => "x{$n}", 'amount' => 10],
            'inventory_unit_logs'           => ['inventory_item_id' => $this->row('inventory_items', 'name', "Item u{$n}"), 'action' => 'found', 'quantity' => 1],
            'event_inventory_releases'      => ['event_id' => $this->eventId(), 'inventory_item_id' => $this->row('inventory_items', 'name', "Item r{$n}"), 'quantity' => 1],
            'event_inventory_release_undos' => ['event_inventory_release_id' => $this->row('event_inventory_releases', 'quantity', 1), 'quantity' => 1],
        };
        $row[$column] = $value;

        return DB::table($table)->insertGetId($row);
    }

    private function refused(callable $fn): bool
    {
        try {
            $fn();
        } catch (QueryException) {
            return true;
        }

        return false;
    }

    private const PHOTO_COLUMNS = [
        ['users', 'validation_id'],
        ['inventory_items', 'photo_path'],
        ['event_inventory_releases', 'evidence_photo_path'],
        ['event_inventory_releases', 'undo_photo_path'],
        ['event_inventory_release_undos', 'photo_path'],
        ['inventory_unit_logs', 'photo_path'],
    ];

    // ------------------------------------------------------------ the database

    public function test_every_photo_column_takes_jpg_jpeg_png_in_any_case_and_refuses_everything_else(): void
    {
        foreach (self::PHOTO_COLUMNS as [$table, $column]) {
            foreach (['a/b.jpg', 'a/b.JPEG', 'a/b.Png', 'a/b.png', null] as $ok) {
                $this->row($table, $column, $ok);
            }
            foreach (['a/b.gif', 'a/b.webp', 'a/b.svg', 'a/b.pdf', 'a/b.php', 'a/b.png.php', 'a/b.exe', 'a/b', ''] as $bad) {
                $this->assertTrue($this->refused(fn () => $this->row($table, $column, $bad)), "{$table}.{$column} accepted '{$bad}'");
            }
        }
    }

    public function test_receipts_also_take_pdf_but_nothing_else(): void
    {
        foreach (['r/a.pdf', 'r/a.PDF', 'r/a.jpg', 'r/a.png'] as $ok) {
            $this->row('event_expenses', 'receipt_path', $ok);
        }
        foreach (['r/a.gif', 'r/a.docx', 'r/a.php', 'r/a.html'] as $bad) {
            $this->assertTrue($this->refused(fn () => $this->row('event_expenses', 'receipt_path', $bad)), "receipt accepted '{$bad}'");
        }
    }

    public function test_changing_a_stored_path_to_a_bad_one_is_refused_but_a_good_one_or_null_is_fine(): void
    {
        $id = $this->row('inventory_items', 'photo_path', 'inventory_photos/a.png');

        DB::table('inventory_items')->where('id', $id)->update(['photo_path' => 'inventory_photos/b.jpg']);
        DB::table('inventory_items')->where('id', $id)->update(['photo_path' => null]);
        $this->assertTrue($this->refused(fn () => DB::table('inventory_items')->where('id', $id)->update(['photo_path' => 'x.gif'])));
        $this->assertNull(DB::table('inventory_items')->find($id)->photo_path);
    }

    public function test_lists_of_files_are_checked_element_by_element_and_capped(): void
    {
        $this->row('event_expenses', 'extra_receipt_paths', json_encode(['a.pdf', 'b.png']));
        $this->row('event_expenses', 'extra_receipt_paths', null);
        $this->row('inventory_unit_logs', 'extra_photo_paths', json_encode(['a.jpg', 'b.png']));

        $this->assertTrue($this->refused(fn () => $this->row('event_expenses', 'extra_receipt_paths', json_encode(['a.png', 'b.gif']))));
        $this->assertTrue($this->refused(fn () => $this->row('inventory_unit_logs', 'extra_photo_paths', json_encode(['a.png', 'b.pdf']))));
        $this->assertTrue($this->refused(fn () => $this->row('event_inventory_releases', 'extra_evidence_photo_paths', json_encode(array_fill(0, 11, 'a.png')))));
        $this->row('event_inventory_releases', 'extra_evidence_photo_paths', json_encode(array_fill(0, 10, 'a.png')));
    }

    public function test_files_saved_before_the_lock_are_left_alone_and_their_rows_stay_editable(): void
    {
        $m = $this->migration();
        $m->down();                                                       // as it was before the lock
        $id = $this->row('inventory_items', 'photo_path', 'inventory_photos/old.webp');
        $m->up();

        DB::table('inventory_items')->where('id', $id)->update(['name' => 'Renamed']);      // not touching the photo
        $this->assertSame('inventory_photos/old.webp', DB::table('inventory_items')->find($id)->photo_path);

        $this->assertTrue($this->refused(fn () => DB::table('inventory_items')->where('id', $id)->update(['photo_path' => 'new.gif'])));
        DB::table('inventory_items')->where('id', $id)->update(['photo_path' => 'inventory_photos/new.png']);
        $this->assertSame('inventory_photos/new.png', DB::table('inventory_items')->find($id)->photo_path);
    }

    public function test_the_migration_can_run_twice(): void
    {
        $m = $this->migration();
        $m->up();
        $m->up();
        $this->assertTrue($this->refused(fn () => $this->row('inventory_items', 'photo_path', 'x.gif')));
    }

    // ------------------------------------------------------------ the app

    private function residentPayload(array $extra = []): array
    {
        static $n = 0;
        $n++;
        return array_merge([
            'first_name' => 'Ana' . $n, 'last_name' => 'Reyes' . $n, 'contact_number' => '09171230' . str_pad((string) $n, 3, '0', STR_PAD_LEFT),
            'role' => 'Resident', 'has_account' => false,
        ], $extra);
    }

    public function test_a_validation_id_must_be_a_jpg_or_png(): void
    {
        Storage::fake('public');
        $staff = $this->staff();

        $gif = UploadedFile::fake()->createWithContent('id.gif', base64_decode(self::GIF));
        $this->actingAs($staff)->post('/users', $this->residentPayload(['validation_id' => $gif]), ['Accept' => 'application/json'])
            ->assertStatus(422)->assertJsonValidationErrors('validation_id');

        $pdf = UploadedFile::fake()->create('id.pdf', 20, 'application/pdf');
        $this->actingAs($staff)->post('/users', $this->residentPayload(['validation_id' => $pdf]), ['Accept' => 'application/json'])
            ->assertStatus(422)->assertJsonValidationErrors('validation_id');

        $png = UploadedFile::fake()->createWithContent('id.png', base64_decode(self::PNG));
        $this->actingAs($staff)->post('/users', $this->residentPayload(['validation_id' => $png]), ['Accept' => 'application/json'])->assertStatus(201);
        $this->assertStringEndsWith('.png', DB::table('users')->orderByDesc('id')->value('validation_id'));
    }

    public function test_a_file_is_judged_by_its_content_and_its_name_together(): void
    {
        Storage::fake('public');
        $staff = $this->staff();
        $post = fn (UploadedFile $f) => $this->actingAs($staff)->post('/users', $this->residentPayload(['validation_id' => $f]), ['Accept' => 'application/json']);

        $post($this->realFile('shell.php', self::PNG))->assertStatus(422);     // a PNG called .php
        $post($this->realFile('id.png', self::GIF))->assertStatus(422);        // a GIF called .png

        $post($this->realFile('id.jpeg', self::PNG))->assertStatus(201);       // content PNG, name .jpeg: accepted, stored by its content
        $path = DB::table('users')->orderByDesc('id')->value('validation_id');
        $this->assertStringEndsWith('.png', $path);
        $this->assertStringNotContainsString('.jpeg', $path);
        Storage::disk('public')->assertExists($path);
    }

    public function test_the_extension_helper_decides_from_the_content(): void
    {
        $png = $this->realFile('x.jpeg', self::PNG);
        $this->assertSame('png', Uploads::extension($png, Uploads::IMAGE));

        $gif = $this->realFile('x.png', self::GIF);
        $this->expectException(\App\Exceptions\UserFacingException::class);
        Uploads::extension($gif, Uploads::IMAGE);
    }

    public function test_a_receipt_may_be_a_pdf_a_photo_but_not_a_gif(): void
    {
        Storage::fake('public');
        $event = Event::create([
            'name' => 'Fiesta', 'description' => 'd', 'location' => 'Hall', 'event_start' => now()->addHours(3), 'event_end' => now()->addHours(5),
            'call_time_start' => now()->subHour(), 'call_time_end' => now()->addHours(6), 'approved_budget' => 1000,
        ]);
        $staff = $this->staff();

        $pdf = UploadedFile::fake()->create('r.pdf', 20, 'application/pdf');
        $this->actingAs($staff)->post("/events/{$event->id}/expenses", ['item' => 'Food', 'amount' => 100, 'receipt' => $pdf], ['Accept' => 'application/json'])->assertSuccessful();

        $gif = UploadedFile::fake()->createWithContent('r.gif', base64_decode(self::GIF));
        $this->actingAs($staff)->post("/events/{$event->id}/expenses", ['item' => 'Rice', 'amount' => 100, 'receipt' => $gif], ['Accept' => 'application/json'])
            ->assertStatus(422)->assertJsonValidationErrors('receipt');

        $this->assertSame(1, DB::table('event_expenses')->count());
    }
}
