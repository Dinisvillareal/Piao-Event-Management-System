import KpiCard from "../../../components/ui/KpiCard";
import { scrollListIntoView } from "../../../lib/scrollToList";
import SaveButton from "../../../components/ui/SaveButton";
import FormDrawer, { FormSection } from "../../../components/ui/FormDrawer";
import useFilterSwitching from "../../../hooks/useFilterSwitching";
import FormSelect from "../../../components/ui/FormSelect";
import { highlightMatches } from "../../../lib/highlight";
import React, { useEffect, useMemo, useState, useRef } from "react";
import { Package, Plus, X, MapPin, Trash2, Pencil, AlertTriangle, Search, Layers, RefreshCw, Eye, ImagePlus, Filter, ChevronLeft, ChevronRight, CheckCircle2 } from "lucide-react";
import FilterBar, { type ExtraChip } from "../../../components/ui/FilterBar";
import QuickTabs from "../../../components/ui/QuickTabs";
import ConfirmDialog from "../../../components/ui/ConfirmDialog";
import StatusModal from "../../../components/ui/StatusModal";
import NumberStepper from "../../../components/ui/NumberStepper";
import PhotoAttachment from "../../../components/ui/PhotoAttachment";
import { PhotoItem, photoItemsFromUrls, photoItemsChanged } from "../../../components/ui/PhotoGallery";
import Skeleton from "../../../components/ui/Skeleton";
import PhotoViewer from "../../../components/ui/PhotoViewer";
import api, { apiErrorMessage } from "../../../lib/api";
import { useLanguage } from "../../../i18n/LanguageContext";
import StatCardSkeleton, { usePageOpenSkeleton } from "../../../components/ui/StatCardSkeleton";

import { tc } from "../../../lib/contentTranslations";
import PagerSkeleton from "../../../components/ui/PagerSkeleton";
import Portal from "../../../components/ui/Portal";
import UnitsModal from "../../../components/inventory/UnitsModal";
// An item's condition covers the units still in use. Lost units are a separate
// counter on the item, so "Lost" is only a *filter*, not a condition.
type Condition = "New" | "Good" | "Fair" | "Poor";
type ConditionFilter = Condition | "Lost";

interface InventoryItem {
  id: number;
  name: string;
  quantity: number;
  // Units reported lost -- separate from `condition`, so a few lost units
  // never mark the still-good ones as Lost.
  lost_quantity: number;
  // Main condition (the one with the most units) -- kept for filters/reports.
  condition: Condition;
  // In-stock units per condition (they add up to `quantity`), so one item can
  // hold e.g. 45 Good + 15 New instead of needing a duplicate row.
  new_quantity: number;
  good_quantity: number;
  fair_quantity: number;
  poor_quantity: number;
  storage_location: string | null;
  notes: string | null;
  photo_url: string | null;
  // How many units are currently lent out to a still-active event (see
  // InventoryItem::borrows() on the backend). >0 means the item can't be
  // deleted yet -- it has to be returned to Inventory first.
  borrowed_quantity: number;
  // Set when this item is on loan to an event whose date has already
  // passed and nobody has archived it yet -- the item is effectively
  // stuck, since nothing returns it to Inventory automatically.
  overdue_borrow_event: { id: number; name: string; ended_at: string } | null;
}

// Dark-palette badges -- same semantic hue mapping as the light styles
// they replace (teal for good condition, gold for caution, rust/red for
// needing attention), matching the navy/gold/teal system used everywhere
// else (Dashboard, Residents, Households, Events).
const CONDITION_STYLES: Record<Condition, string> = {
  New: "bg-[#4FBEB0]/20 text-[#7DD8CB]",
  Good: "bg-[#4FBEB0]/10 text-[#7DD8CB]",
  Fair: "bg-gold-400/15 text-gold-300",
  Poor: "bg-[#8A3D2C]/25 text-[#E2A088]",
};

const CONDITIONS: Condition[] = ["New", "Good", "Fair", "Poor"];
const COUNT_KEY = { New: "new_quantity", Good: "good_quantity", Fair: "fair_quantity", Poor: "poor_quantity" } as const;

// In-stock units of one item per condition, non-empty ones only. An item with
// nothing in stock still shows its main condition (with 0 units).
const conditionUnits = (item: InventoryItem): { condition: Condition; units: number }[] => {
  const rows = CONDITIONS.map((c) => ({ condition: c, units: Number(item[COUNT_KEY[c]]) || 0 })).filter((r) => r.units > 0);
  return rows.length ? rows : [{ condition: item.condition, units: 0 }];
};

const emptyForm = {
  name: "",
  new_quantity: 0,
  good_quantity: 1,
  fair_quantity: 0,
  poor_quantity: 0,
  storage_location: "",
  notes: "",
};

const formFromItem = (item: InventoryItem) => ({
  name: item.name,
  new_quantity: Number(item.new_quantity) || 0,
  good_quantity: Number(item.good_quantity) || 0,
  fair_quantity: Number(item.fair_quantity) || 0,
  poor_quantity: Number(item.poor_quantity) || 0,
  storage_location: item.storage_location ?? "",
  notes: item.notes ?? "",
});

const CONDITION_LABEL_KEYS: Record<ConditionFilter, string> = {
  New: "conditionNew",
  Good: "conditionGood",
  Fair: "conditionFair",
  Poor: "conditionPoor",
  Lost: "conditionLost",
};

/**
 * UC-9: Manage Barangay Inventory. Laid out like a live ops dashboard --
 * a KPI strip up top (total items, units on hand, on loan, needing
 * attention) driven by a quietly self-refreshing dataset, and a dense
 * sortable table below for the actual per-item browsing/editing, instead
 * of the card-grid layout this page used previously.
 */
export default function InventoryView() {
  const { t, language } = useLanguage();
  const [items, setItems] = useState<InventoryItem[]>([]);
  // Paging, filtering and sorting happen on the server; these come back with each page.
  const [meta, setMeta] = useState({ total: 0, last_page: 1 });
  const [tabCounts, setTabCounts] = useState<Record<string, number>>({});
  const fetchSeq = useRef(0);
  const [loading, setLoading] = useState(true);
  // Page-open skeleton for the KPI strip (first load only -- never returns on polls).
  const statsLoading = usePageOpenSkeleton(loading);
  const [search, setSearch] = useState("");
  const [conditionFilter, setConditionFilter] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<InventoryItem | null>(null);
  // Closing the Add/Edit Item modal (X, Cancel, or the backdrop) with
  // unsaved changes asks first instead of silently discarding them.
  const [showFormCancelConfirm, setShowFormCancelConfirm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  // Marks lost units as found for one item (see UnitsModal).
  const [unitsItem, setUnitsItem] = useState<InventoryItem | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  // Brief skeleton flash on every page switch, same as Activity Logs --
  // this list paginates client-side so there's nothing to actually wait
  // on, but the flash keeps page switches feeling consistent app-wide.
  const [pageSwitchingRaw, setPageSwitching] = useState(false);
  type InvTab = "all" | "on-loan" | "low" | "attention";
  const [invTab, setInvTab] = useState<InvTab>("all");
  const [sortKey, setSortKey] = useState("name-az");
  const filterSwitching = useFilterSwitching([search, conditionFilter, invTab, sortKey]);
  const pageSwitching = pageSwitchingRaw || filterSwitching;
  const pageSwitchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const listTopRef = useRef<HTMLSpanElement | null>(null);
  const goToPage = (updater: number | ((p: number) => number)) => {
    setCurrentPage(updater as any);
    scrollListIntoView(listTopRef.current);
    setPageSwitching(true);
    if (pageSwitchTimer.current) clearTimeout(pageSwitchTimer.current);
    pageSwitchTimer.current = setTimeout(() => setPageSwitching(false), 0);
  };
  useEffect(() => () => { if (pageSwitchTimer.current) clearTimeout(pageSwitchTimer.current); }, []);
  const itemsPerPage = 10;

  // Photo state for the Add/Edit form
  // One photo per item: the saved one or a newly picked file (kept as a list
  // of at most one so it shares the save format with the multi-photo fields).
  const [photoItems, setPhotoItems] = useState<PhotoItem[]>([]);

  // Full-size photo viewer (dark themed, matching the rest of the app).
  const [viewingPhoto, setViewingPhoto] = useState<{ url: string; name: string; urls?: string[] } | null>(null);

  // KPI strip data -- deliberately a SEPARATE, always-unfiltered fetch from
  // the search/condition-filtered `items` list below, so the summary
  // numbers at the top of the page stay stable while someone is typing
  // into the search box or narrowing the condition filter, and instead
  // update on their own short interval like a real live dashboard would.
  const [allItems, setAllItems] = useState<InventoryItem[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [nowTick, setNowTick] = useState(() => Date.now());

  const fetchStats = async () => {
    try {
      const res = await api.get("/inventory");
      setAllItems(res.data);
      setLastUpdated(new Date());
    } catch (e) {
      // Silent -- the KPI strip just keeps showing its last good numbers.
      // The search/filter table below has its own fetchItems, which does
      // surface a real error modal if the API is actually unreachable.
    }
  };

  useEffect(() => {
    fetchStats();
    // Refreshes itself every 20s, but skips a tick while the Add/Edit or
    // Delete modal is open so the KPI numbers don't shift under a staff
    // member who's mid-edit.
    const poll = setInterval(() => {
      if (!showForm && deleteId === null) fetchStats();
    }, 20000);
    return () => clearInterval(poll);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showForm, deleteId]);

  useEffect(() => {
    const tick = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(tick);
  }, []);

  const secondsSinceUpdate = lastUpdated ? Math.max(0, Math.floor((nowTick - lastUpdated.getTime()) / 1000)) : null;
  const lastUpdatedLabel =
    secondsSinceUpdate === null
      ? ""
      : secondsSinceUpdate < 5
      ? t("updatedJustNowLabel")
      : secondsSinceUpdate < 60
      ? t("updatedSecondsAgoLabel").replace("{n}", String(secondsSinceUpdate))
      : t("updatedMinutesAgoLabel").replace("{n}", String(Math.floor(secondsSinceUpdate / 60)));

  const stats = useMemo(() => {
    const totalItems = allItems.length;
    const totalUnits = allItems.reduce((sum, i) => sum + (Number(i.quantity) || 0), 0);
    const onLoanCount = allItems.filter((i) => i.borrowed_quantity > 0).length;
    const needsAttentionCount = allItems.filter(
      (i) => !!i.overdue_borrow_event || Number(i.poor_quantity) > 0 || (i.lost_quantity ?? 0) > 0
    ).length;
    return { totalItems, totalUnits, onLoanCount, needsAttentionCount };
  }, [allItems]);

  const fetchItems = async () => {
    // Only the newest request may update the screen (typing fast fires several).
    const seq = ++fetchSeq.current;
    setLoading(true);
    try {
      const res = await api.get("/inventory", {
        params: { paged: 1, search, condition: conditionFilter, tab: invTab, sort: sortKey, page: currentPage, per_page: itemsPerPage },
      });
      if (seq !== fetchSeq.current) return;
      const { data, meta: m, counts } = res.data;
      // A page past the end (e.g. after the last row of a page was removed): go back.
      if (m.last_page < currentPage) {
        setCurrentPage(Math.max(1, m.last_page));
        return;
      }
      setItems(data);
      setMeta({ total: m.total, last_page: m.last_page });
      setTabCounts(counts ?? {});
    } catch (e) {
      if (seq === fetchSeq.current) setError(apiErrorMessage(e, t("loadInventoryFailed")));
    } finally {
      if (seq === fetchSeq.current) setLoading(false);
    }
  };

  // Any filter change starts again from page 1.
  useEffect(() => {
    setCurrentPage(1);
  }, [search, conditionFilter, invTab, sortKey]);

  useEffect(() => {
    const timer = setTimeout(fetchItems, 120);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, conditionFilter, invTab, sortKey, currentPage]);

  // Keep the open Units drawer in step with fresh stock numbers after a save.
  useEffect(() => {
    setUnitsItem((cur) => (cur ? items.find((i) => i.id === cur.id) ?? cur : cur));
  }, [items]);

  // Quick tabs, sorting and paging are done by the server (see InventoryController::index);
  // each tab's count comes back with the page.
  const tabCount = (k: InvTab) => tabCounts[k] ?? 0;
  const viewItems = items;
  const tabLabels: Record<InvTab, string> = {
    all: t("tabAll"), "on-loan": t("tabOnLoan"), low: t("tabLowStock"), attention: t("tabNeedsAttention"),
  };
  const invTabChips: ExtraChip[] = invTab === "all" ? [] : [{ key: "tab", label: tabLabels[invTab], onRemove: () => setInvTab("all") }];

  const totalPages = Math.max(1, meta.last_page);
  const paginatedItems = viewItems;

  // Nothing to submit if editing an item and the form still matches its
  // original values -- keeps a no-op "Update Item" click (and its own
  // success popup) from firing for a change that never happened. A chosen
  // or removed photo counts as a change too.
  const isFormUnchanged = !!editing && (
    form.name === editing.name &&
    Number(form.new_quantity) === (Number(editing.new_quantity) || 0) &&
    Number(form.good_quantity) === (Number(editing.good_quantity) || 0) &&
    Number(form.fair_quantity) === (Number(editing.fair_quantity) || 0) &&
    Number(form.poor_quantity) === (Number(editing.poor_quantity) || 0) &&
    form.storage_location === (editing.storage_location ?? "") &&
    form.notes === (editing.notes ?? "") &&
    !photoItemsChanged(photoItems, editing.photo_url ? 1 : 0)
  );

  const hasFormChanges = editing
    ? !isFormUnchanged
    : JSON.stringify(form) !== JSON.stringify(emptyForm) || photoItems.length > 0;

  const handleCloseForm = () => {
    if (hasFormChanges) setShowFormCancelConfirm(true);
    else closeForm();
  };

  const baseQuantity = CONDITIONS.reduce((sum, c) => sum + (Number(form[COUNT_KEY[c]]) || 0), 0);
  // Main condition (only used in the saved-message wording): the one holding the most units.
  const mainCondition: Condition = baseQuantity > 0
    ? ([...CONDITIONS].reverse().reduce((best, c) => (Number(form[COUNT_KEY[c]]) > Number(form[COUNT_KEY[best]]) ? c : best), "Poor" as Condition))
    : (editing?.condition ?? "Good");
  const shownQuantity = baseQuantity;
  // Picking a photo replaces the current one -- an item holds exactly one.
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!["image/jpeg", "image/png"].includes(file.type)) {
      setError(t("uploadImageOnly"));
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError(t("photoTooLarge"));
      return;
    }
    const old = photoItems[0];
    if (old?.file) URL.revokeObjectURL(old.url);
    setPhotoItems([{ id: `photo-${Date.now()}`, url: URL.createObjectURL(file), file, existingIndex: null }]);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditing(null);
    setForm(emptyForm);
    setPhotoItems([]);
  };

  const openAdd = () => {
    setEditing(null);
    setForm(emptyForm);
    setPhotoItems([]);
    setError(null);
    setShowForm(true);
  };

  const openEdit = (item: InventoryItem) => {
    setEditing(item);
    setForm(formFromItem(item));
    setPhotoItems(photoItemsFromUrls(item.photo_url ? [item.photo_url] : []));
    setError(null);
    setShowForm(true);
  };

  // Form submit only opens the "are you sure" step -- the actual save
  // happens in performSave, once the user confirms. The form now carries
  // noValidate (see below), so this is the ONLY thing standing between a
  // bad value and the API -- the browser's own "please enter a valid
  // value" bubble no longer fires, on purpose, in favor of the app's own
  // error modal below.
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // An item always keeps at least one photo -- a brand-new item with
    // nothing chosen yet, or an existing item whose photos were all removed
    // -- so this one check covers both the Add and Edit forms.
    if (photoItems.length === 0) {
      setError(t("photoRequiredError"));
      return;
    }
    if (!form.name.trim()) {
      setError(t("itemNameRequiredError"));
      return;
    }
    if (CONDITIONS.some((c) => !Number.isInteger(form[COUNT_KEY[c]]) || form[COUNT_KEY[c]] < 0)) {
      setError(t("invalidQuantityError"));
      return;
    }

    setShowConfirm(true);
  };

  const performSave = async () => {
    setShowConfirm(false);
    setError(null);
    const wasEditing = !!editing;

    try {
      const fd = new FormData();
      fd.append("name", form.name);
      // Units per condition; the server adds them up into the in-stock quantity.
      CONDITIONS.forEach((c) => fd.append(COUNT_KEY[c], String(form[COUNT_KEY[c]])));
      fd.append("quantity", String(baseQuantity));
      if (form.storage_location) fd.append("storage_location", form.storage_location);
      if (form.notes) fd.append("notes", form.notes);

      // An item holds one photo: only send it when a new file was picked.
      if (photoItems[0]?.file) fd.append("photo", photoItems[0].file);

      if (editing) {
        // The counts this form was opened with, so the server can tell if the stock moved meanwhile.
        CONDITIONS.forEach((c) => fd.append(`base_${COUNT_KEY[c]}`, String(Number(editing[COUNT_KEY[c]]) || 0)));
      }

      let archived = false;
      if (editing) {
        fd.append("_method", "PUT");
        const res = await api.post(`/inventory/${editing.id}`, fd);
        archived = !!res?.data?.archived;
      } else {
        await api.post("/inventory", fd);
      }

      closeForm();
      setSuccessMessage(
        archived
          ? t("itemArchivedSuccess").replace("{condition}", mainCondition)
          : wasEditing
          ? t("itemUpdatedSuccess")
          : t("itemAddedSuccess")
      );
      fetchItems();
      fetchStats();
    } catch (e) {
      setError(apiErrorMessage(e, t("saveItemFailed")));
      // Revert to the item's real values instead of leaving the
      // rejected edit sitting in the form.
      if (editing) {
        setForm(formFromItem(editing));
      }
    }
  };


  const handleDelete = async () => {
    if (deleteId === null) return;
    try {
      await api.delete(`/inventory/${deleteId}`);
      setDeleteId(null);
      setSuccessMessage(t("itemDeletedSuccess"));
      fetchItems();
      fetchStats();
    } catch (e) {
      setDeleteId(null);
      setError(apiErrorMessage(e, t("deleteItemFailed")));
    }
  };

  return (
    <>
    {/* Full-bleed dark navy page -- same technique and palette as the
        Dashboard/Residents/Households/Events pages, so Inventory reads as
        part of the same system instead of the old light "paper" page.
        Confirm/success/error/delete modals further below stay on their
        original light theme, same scoping used on every other staff view. */}
    <div className="-m-3 sm:-m-6 min-h-[calc(100dvh-73px)] bg-[#0A0E1A] p-4 sm:p-8">
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">{t("barangayInventory")}</h1>
          <p className="mt-1.5 text-sm text-white/50 max-w-xl">{t("inventorySubtitle")}</p>
        </div>
        <div className="flex items-center gap-2.5 self-start sm:self-auto shrink-0">
          {/* Genuinely live -- fetchStats() re-polls /inventory every 20s
              (see effect above), this just renders how long ago that last
              landed, ticking every second off nowTick. */}
          <div className="hidden sm:inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-2 text-xs font-medium text-white/50" title={t("liveLabel")}>
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#4FBEB0] opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[#4FBEB0]" />
            </span>
            {lastUpdatedLabel}
          </div>
          <button
            onClick={openAdd}
            disabled={loading || pageSwitching}
            className="group inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.04] pl-6 pr-2 py-2 text-base font-semibold text-white shadow-sm transition-all duration-500 ease-out hover:border-[#1E3A5F] hover:bg-[#1E3A5F] hover:shadow-md shrink-0 disabled:pointer-events-none disabled:opacity-50"
          >
            {t("addItem")}
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#0A0E1A] transition-colors duration-500 ease-out group-hover:bg-white/15">
              <Plus className="h-5 w-5 text-white" />
            </span>
          </button>
        </div>
      </div>

      {/* KPI strip -- same gradient-card language as the Dashboard's stat
          strip, so "at a glance" reads the same way on both pages. */}
      <div className="report-stagger grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {[
          { value: stats.totalItems, label: t("totalItemsStatLabel"), description: t("totalItemsStatDesc"), icon: Package, gradient: "from-sage-400 to-sage-700" },
          { value: stats.totalUnits, label: t("unitsInStockStatLabel"), description: t("unitsInStockStatDesc"), icon: Layers, gradient: "from-sage-800 to-[#1C2E2B]" },
          { value: stats.onLoanCount, label: t("onLoanStatLabel"), description: t("onLoanStatDesc"), icon: RefreshCw, gradient: "from-gold-400 to-gold-700" },
          { value: stats.needsAttentionCount, label: t("needsAttentionStatLabel"), description: t("needsAttentionStatDesc"), icon: AlertTriangle, gradient: "from-[#8A3D2C] to-[#5C2A1E]" },
        ].map((card, idx) => statsLoading ? (
          <StatCardSkeleton key={idx} />
        ) : (
          <KpiCard key={idx} value={card.value} label={card.label} description={card.description} icon={card.icon} gradient={card.gradient} delay={idx * 70} />
        ))}
      </div>

      <div className="space-y-4 rounded-2xl border border-white/10 bg-white/[0.04] p-3 sm:p-4">
        <QuickTabs
          value={invTab}
          onChange={(k) => setInvTab(k as InvTab)}
          tabs={([
            ["all", false], ["on-loan", false], ["low", true], ["attention", true],
          ] as [InvTab, boolean][]).map(([k, alert]) => ({ key: k, label: tabLabels[k], count: tabCount(k), alert }))}
        />
        <FilterBar
          search={{ value: search, onChange: setSearch, placeholder: t("searchInventoryPlaceholder") }}
          filters={[{
            key: "condition", label: t("conditionColumn"), value: conditionFilter, defaultValue: "", onChange: setConditionFilter,
            options: [
              { value: "", label: t("allConditions") },
              ...(["New", "Good", "Fair", "Poor", "Lost"] as ConditionFilter[]).map((c) => ({ value: c, label: t(CONDITION_LABEL_KEYS[c]) })),
            ],
          }]}
          sort={{
            value: sortKey, onChange: setSortKey,
            options: [
              { value: "name-az", label: t("sortNameAZ") },
              { value: "name-za", label: t("sortNameZA") },
              { value: "qty-high", label: t("sortQtyHigh") },
              { value: "qty-low", label: t("sortQtyLow") },
              { value: "recent", label: t("sortRecentlyAdded") },
            ],
          }}
          count={{ shown: meta.total, total: allItems.length || meta.total }}
          extraChips={invTabChips}
          onClearExtras={() => setInvTab("all")}
        />
      </div>

      <span ref={listTopRef} className="block h-0 w-0 !m-0 scroll-mt-24" />
      {loading || pageSwitching ? (
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] overflow-hidden shadow-sm">
          <div className="border-b border-white/10 px-4 py-3">
            <Skeleton className="h-3 w-24" />
          </div>
          <div className="divide-y divide-white/[0.06]">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-4 py-3.5">
                <Skeleton className="h-9 w-9 shrink-0 rounded-full" />
                <Skeleton className="h-4 w-40" />
                <Skeleton className="h-4 w-16 ml-auto" />
                <Skeleton className="h-4 w-14" />
                <Skeleton className="h-4 w-24 hidden sm:block" />
                <Skeleton className="h-6 w-16 rounded-full" />
              </div>
            ))}
          </div>
        </div>
      ) : viewItems.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.03] p-10 text-center text-white/50">
          <Package size={40} className="mx-auto mb-3 text-white/20" />
          <p>{items.length === 0 && !search && !conditionFilter ? t("noInventoryItems") : t("fltNoMatches")}</p>
        </div>
      ) : (
        <>
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="rtable w-full text-sm">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="py-3 px-4 text-left text-xs font-bold uppercase tracking-wide text-white">{t("itemColumn")}</th>
                  <th className="py-3 px-4 text-left text-xs font-bold uppercase tracking-wide text-white">{t("conditionColumn")}</th>
                  <th className="py-3 px-4 text-left text-xs font-bold uppercase tracking-wide text-white">{t("quantityColumn")}</th>
                  <th className="py-3 px-4 text-left text-xs font-bold uppercase tracking-wide text-white">{t("storageLocationLabel")}</th>
                  <th className="py-3 px-4 text-left text-xs font-bold uppercase tracking-wide text-white">{t("statusColumn")}</th>
                  <th className="py-3 px-4 text-right text-xs font-bold uppercase tracking-wide text-white">{t("actionsColumn")}</th>
                </tr>
              </thead>
              <tbody>
                {paginatedItems.map((item) => (
                  <tr key={item.id} className="border-b border-white/[0.06] last:border-0 hover:bg-white/[0.05] transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="relative shrink-0">
                          <div className="h-9 w-9 rounded-full bg-[#123A38] border border-white/10 text-[#7DD8CB] overflow-hidden flex items-center justify-center">
                            {item.photo_url ? (
                              <img src={item.photo_url} alt="" className="h-full w-full object-cover" />
                            ) : (
                              <Package className="h-4 w-4" />
                            )}
                          </div>
                          {item.photo_url && (
                            <button
                              type="button"
                              onClick={() => setViewingPhoto({ url: item.photo_url as string, name: item.name })}
                              title={t("viewPhotoLabel")}
                              className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full bg-[#0A0E1A] border border-white/20 text-white/60 hover:text-[#7DD8CB] hover:border-[#4FBEB0]/50 flex items-center justify-center transition"
                            >
                              <Eye className="h-2.5 w-2.5" />
                            </button>
                          )}
                        </div>
                        <div className="min-w-0 max-w-[280px]">
                          <p className="text-[15px] font-semibold text-white truncate" title={tc(item.name, language as any)}>{highlightMatches(tc(item.name, language as any), search)}</p>
                          {item.notes && (
                            <p className="text-[13px] text-white/40 leading-snug mt-0.5 line-clamp-2" title={tc(item.notes, language as any)}>{highlightMatches(tc(item.notes, language as any), search)}</p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {conditionUnits(item).map((r) => (
                          <span key={r.condition} className={`px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap [font-variant-numeric:tabular-nums] ${CONDITION_STYLES[r.condition]}`}>
                            {r.units} {t(CONDITION_LABEL_KEYS[r.condition])}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-[15px] font-semibold text-white [font-variant-numeric:tabular-nums]">
                      {item.quantity} <span className="font-normal text-[13px] text-white/45">{t("inStock")}</span>
                      {item.lost_quantity > 0 && (
                        <span
                          className="ml-2 inline-flex items-center rounded-full bg-red-500/15 px-2 py-0.5 text-xs font-semibold text-red-400 whitespace-nowrap"
                        >
                          {t("lostUnitsBadge").replace("{n}", String(item.lost_quantity))}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-[15px] text-white/50">
                      {item.storage_location ? (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4 shrink-0 text-[#4FBEB0]" /> {tc(item.storage_location, language as any)}
                        </span>
                      ) : "—"}
                    </td>
                    <td className="py-3 px-4">
                      {item.overdue_borrow_event ? (
                        <span
                          className="px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/15 text-red-400 whitespace-nowrap"
                          title={t("overdueBorrowTooltip").replace("{event}", item.overdue_borrow_event.name)}
                        >
                          {t("overdueReturnBadge")}
                        </span>
                      ) : item.borrowed_quantity > 0 ? (
                        <span className="px-2.5 py-1 rounded-full text-xs font-semibold border border-white/10 bg-white/[0.04] text-white/50 whitespace-nowrap">{t("onLoanBadge")}</span>
                      ) : (
                        <span className="text-white/25">—</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {/* Neutral with a white hover for Edit, red hover for
                          Delete -- matches the icon-only Edit/Delete
                          pairing used elsewhere on the dark pages. Delete
                          is disabled while any units are out on loan --
                          deleting an item an active event still points to
                          would orphan its borrow record (see
                          InventoryController::destroy). */}
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setUnitsItem(item)}
                          className="inline-flex h-10 w-10 items-center justify-center rounded-full transition sm:h-8 sm:w-8 text-white/50 hover:bg-white/10 hover:text-white"
                          title={t("unitsButtonTitle")}
                        >
                          <Layers className="h-4 w-4" />
                        </button>
                        <button onClick={() => openEdit(item)} className="inline-flex h-10 w-10 items-center justify-center rounded-full text-white/50 hover:bg-white/10 hover:text-white transition sm:h-8 sm:w-8" title={t("editLabel")}>
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => item.borrowed_quantity === 0 && setDeleteId(item.id)}
                          disabled={item.borrowed_quantity > 0}
                          className={`inline-flex h-10 w-10 items-center justify-center rounded-full transition sm:h-8 sm:w-8 ${
                            item.borrowed_quantity > 0
                              ? "text-white/20 cursor-not-allowed"
                              : "text-white/50 hover:bg-red-500/10 hover:text-red-400"
                          }`}
                          title={item.borrowed_quantity > 0 ? t("itemCurrentlyBorrowedTooltip") : t("removeLabel")}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {totalPages > 1 && ((pageSwitching || loading) ? <PagerSkeleton withLabel className="px-4 py-3 border-t border-white/10" /> : (
            <div className="flex flex-col sm:flex-row gap-3 justify-between items-center px-4 py-3 border-t border-white/10">
              <p className="text-sm text-white/45 text-center sm:text-left">
                {t("pageOfLabel")} {currentPage} {t("ofPagesLabel")} {totalPages} • {loading || pageSwitching ? 0 : viewItems.length} {t("recordsShownLabel")}
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => goToPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="h-8 w-8 rounded-full border border-white/10 bg-white/[0.04] text-white/70 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white/[0.08] transition"
                >
                  ←
                </button>
                <span className="h-8 w-8 rounded-full bg-sage-700 text-white shadow-sm flex items-center justify-center text-sm font-bold">
                  {currentPage}
                </span>
                <button
                  onClick={() => goToPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="h-8 w-8 rounded-full border border-white/10 bg-white/[0.04] text-white/70 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white/[0.08] transition"
                >
                  →
                </button>
              </div>
            </div>
          ))}
        </div>
        </>
      )}
      </div>
      </div>

      {/* Add/Edit Item modal -- dark navy card, same treatment as the
          Households Edit modal (centered card rather than a full-page
          takeover, since this form is small). */}
      {showForm && (
        <FormDrawer
          title={editing ? t("editItem") : t("addInventoryItem")}
          onClose={handleCloseForm}
          onSubmit={handleFormSubmit}
          footer={<SaveButton className="w-full" active={hasFormChanges} title={!hasFormChanges ? t("noChangesToSaveHint") : undefined}>{editing ? t("updateItem") : t("addItem")}</SaveButton>}
        >
          <FormSection title={t("secItemDetails")} className="space-y-5">
              <div>
                <label className="block text-base font-semibold text-white mb-1.5">{t("photoRequiredLabel")}</label>
                <PhotoAttachment
                  file={photoItems[0]?.file ?? null}
                  url={photoItems[0]?.url ?? null}
                  onPick={handlePhotoChange}
                  onPreview={() => photoItems[0] && setViewingPhoto({ url: photoItems[0].url, name: form.name || t("itemPhotoFallbackLabel") })}
                  onDelete={() => setPhotoItems([])}
                />
                <p className="mt-2 text-sm text-white/50">{t("fileHintImage")}</p>
              </div>

              <div>
                <label className="block text-base font-semibold text-white mb-1.5">{t("itemNameRequired")}</label>
                <input required value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} className="w-full rounded-full border border-white/25 px-5 py-3.5 text-base bg-white/10 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#4FBEB0]/20 focus:border-[#4FBEB0]/50" placeholder={t("opsPlaceholderPlasticChairs")} />
              </div>
          </FormSection>
          <FormSection title={t("secStock")} className="space-y-5">
              <div>
                <label className="block text-base font-semibold text-white mb-1.5">{t("conditionUnitsLabel")}</label>
                <div className="grid grid-cols-2 2xl:grid-cols-4 gap-x-3 gap-y-4">
                  {CONDITIONS.map((c) => (
                    <div key={c} className="min-w-0">
                      <span className={`mb-1.5 inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold ${CONDITION_STYLES[c]}`}>{t(CONDITION_LABEL_KEYS[c])}</span>
                      <NumberStepper
                        min={0}
                        fullWidth
                        value={String(form[COUNT_KEY[c]])}
                        onChange={(v) => setForm((p) => ({ ...p, [COUNT_KEY[c]]: Math.max(0, Math.floor(Number(v) || 0)) }))}
                        className="w-full rounded-full border border-white/25 bg-white/10 pl-4 pr-7 py-3 text-base font-sans text-white [font-variant-numeric:tabular-nums] placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#4FBEB0]/20 focus:border-[#4FBEB0]/50" />
                    </div>
                  ))}
                </div>
                <p className="mt-2 text-sm text-white/60 [font-variant-numeric:tabular-nums]">
                  {t("totalInStockLabel")}: <span className="font-semibold text-white">{shownQuantity}</span>
                </p>
              </div>
              {editing && (
                <p className="text-sm text-white/45">{t("editStockHint")}</p>
              )}
          </FormSection>
          <FormSection title={t("secAdditionalInfo")} className="space-y-5">
              <div>
                <label className="block text-base font-semibold text-white mb-1.5">{t("storageLocationLabel")}</label>
                <input value={form.storage_location} onChange={(e) => setForm((p) => ({ ...p, storage_location: e.target.value }))} className="w-full rounded-full border border-white/25 px-5 py-3.5 text-base bg-white/10 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#4FBEB0]/20 focus:border-[#4FBEB0]/50" placeholder={t("storageLocationPlaceholder")} />
              </div>
              <div>
                <label className="block text-base font-semibold text-white mb-1.5">{t("notesLabel")}</label>
                <textarea value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} className="w-full rounded-3xl border border-white/25 px-5 py-3.5 text-base bg-white/10 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#4FBEB0]/20 focus:border-[#4FBEB0]/50" rows={3} />
              </div>
          </FormSection>
        </FormDrawer>
      )}

      {/* Unsaved-changes guard for the Add/Edit Item modal */}
      {showFormCancelConfirm && (
        <Portal><div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[60] px-4" onClick={() => setShowFormCancelConfirm(false)}>
          <div className="bg-[#0A0E1A] border border-white/10 rounded-[30px] w-full max-w-md p-6 shadow-2xl text-center max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 text-amber-400 flex justify-center"><AlertTriangle size={40} /></div>
            <h3 className="text-xl font-bold text-amber-400 mb-3">{t("unsavedChangesTitle")}</h3>
            <p className="text-white/50 mb-5">{t("unsavedChangesMessage")}</p>
            <div className="flex justify-center gap-4">
              <button onClick={() => setShowFormCancelConfirm(false)} className="px-5 py-2.5 rounded-full border border-white/15 text-white hover:bg-white/10 transition">{t("stayButton")}</button>
              <button
                onClick={() => {
                  setShowFormCancelConfirm(false);
                  closeForm();
                }}
                className="px-5 py-2.5 rounded-full bg-amber-500 text-white hover:bg-amber-600 transition"
              >
                {t("discardCloseButton")}
              </button>
            </div>
          </div>
        </div></Portal>
      )}

      <StatusModal open={!!error} type="error" title={t("errorTitle")} message={error || ""} okLabel={t("okLabel")} onClose={() => setError(null)} z={65} />

      {/* Add / Update / Delete all land here on success, instead of just
          silently closing the form/confirm dialog. */}
      <StatusModal open={!!successMessage} type="success" title={t("successTitle")} message={successMessage || ""} okLabel={t("okLabel")} onClose={() => setSuccessMessage(null)} z={65} />

      {unitsItem && (
        <UnitsModal
          item={unitsItem}
          onClose={() => setUnitsItem(null)}
          onError={setError}
          onViewPhotos={setViewingPhoto}
          onDone={(msg) => {
            setSuccessMessage(msg);
            fetchItems();
            fetchStats();
          }}
        />
      )}

      {deleteId !== null && (
        <Portal><div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[70] px-4">
          <div className="bg-[#0A0E1A] border border-white/10 rounded-[30px] w-full max-w-md p-6 shadow-2xl text-center max-h-[85vh] overflow-y-auto">
            <div className="mb-3 text-red-400 flex justify-center"><Trash2 size={36} /></div>
            <h3 className="text-lg font-bold text-red-400 mb-2">{t("removeItemConfirmTitle")}</h3>
            <p className="text-sm text-white/50 mb-6">{t("removeItemConfirmBody")}</p>
            <div className="flex justify-center gap-3">
              <button onClick={() => setDeleteId(null)} className="px-5 py-2 rounded-full border border-white/15 text-white hover:bg-white/10 transition">{t("cancelLabel")}</button>
              <button onClick={handleDelete} className="px-5 py-2 rounded-full bg-red-500 text-white hover:bg-red-600 transition">{t("yesRemove")}</button>
            </div>
          </div>
        </div></Portal>
      )}

      {/* Confirm-before-save step: shown on top of the open form when
          Add/Update is clicked, so the request only fires once the user
          confirms -- mirrors the delete-confirm pattern above. */}
      <ConfirmDialog
        open={showConfirm}
        icon={editing ? <Pencil size={32} /> : <Plus size={32} />}
        title={editing ? t("confirmUpdateItemTitle") : t("confirmAddItemTitle")}
        body={editing ? t("confirmUpdateItemBody") : t("confirmAddItemBody")}
        cancelLabel={t("cancelLabel")}
        confirmLabel={editing ? t("yesUpdate") : t("yesAdd")}
        onCancel={() => setShowConfirm(false)}
        onConfirm={performSave}
      />

      {/* Full-size photo viewer -- dark themed, matching the rest of the
          app (same treatment as the Delete-confirm and Unsaved-changes
          modals: bg-[#0A0E1A] card, white/10 border, teal accents). */}
      <PhotoViewer
        url={viewingPhoto?.url ?? null}
        name={viewingPhoto ? tc(viewingPhoto.name, language as any) : ""}
        urls={viewingPhoto?.urls}
        onSelect={(u) => setViewingPhoto((cur) => (cur ? { ...cur, url: u } : cur))}
        onClose={() => setViewingPhoto(null)}
      />
    </>
  );
}
