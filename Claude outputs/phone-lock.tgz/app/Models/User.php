<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Support\Phone;
use Illuminate\Support\Facades\Storage;

class User extends Authenticatable
{
    use HasFactory, SoftDeletes;

    public $timestamps = false;

    protected $fillable = [
        'user_code',
        'first_name',
        'last_name',
        'middle_name',
        'suffix',
        'contact_number',
        'validation_id',
        'role',
        'barangay_position',
        'password',
        'has_account',
        'deleted_by',
        'birth_date',
        'address',
        'civil_status_id',
        'gender',
        'household_code',
        'is_household_head',
        'household_contact_number',
        'household_id',
        'preferred_language',
        'must_change_password',
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_secret',
        'failed_login_attempts',
        'locked_until',
        'last_login_ip',
    ];

    protected $casts = [
        'has_account' => 'boolean',
        'is_household_head' => 'boolean',
        'birth_date' => 'date',
        'is_head_staff' => 'boolean',
        'must_change_password' => 'boolean',
        'suspended_at' => 'datetime',
        'locked_until' => 'datetime',
        'last_login_at' => 'datetime',
        'password_changed_at' => 'datetime',
        'two_factor_confirmed_at' => 'datetime',
    ];

    /**
     * Store the mobile number in its one canonical form (09XXXXXXXXX) whatever the
     * way it was typed (0917-123-4567, +63 917 123 4567, ...). A value that is not
     * a valid mobile number is stored untouched, so the database constraint
     * refuses it instead of the app silently changing what was entered.
     */
    public function setContactNumberAttribute($value): void
    {
        $this->attributes['contact_number'] = Phone::canonical($value) ?? $value;
    }

    /**
     * Automatically include in JSON responses
     */
    protected $appends = [
        'two_factor_enabled',
        'validation_id_url',
        'age',
        'age_group',
        'civil_status',
        'current_statuses',
    ];

    // =====================
    // ACCESSOR
    // =====================

    /**
     * Returns:
     * http://127.0.0.1:8000/storage/validation_ids/file.png
     */
    public function getTwoFactorEnabledAttribute(): bool
    {
        return $this->two_factor_confirmed_at !== null;
    }

    public function getValidationIdUrlAttribute(): ?string
    {
        return $this->validation_id
            ? Storage::disk('public')->url($this->validation_id)
            : null;
    }

    // =====================
    // RELATIONSHIPS
    // =====================

    public function attendances()
    {
        return $this->hasMany(
            EventAttendance::class
        );
    }

    public function memberships()
    {
        return $this->belongsToMany(
            Membership::class,
            'membership_residents',
            'user_id',
            'membership_id'
        );
    }

    public function feedback()
    {
        return $this->hasMany(Feedback::class);
    }

    public function household()
    {
        return $this->belongsTo(Household::class);
    }

    // =====================
    // ADVISER RECOMMENDATION: age profiling ("Filter for Age")
    // =====================

    public function getAgeAttribute(): ?int
    {
        if (!$this->birth_date) {
            return null;
        }

        return $this->birth_date->age;
    }

    /**
     * Buckets used across the Residents filter chips and the Reports
     * age-breakdown chart.
     */
    public function getAgeGroupAttribute(): ?string
    {
        $age = $this->age;

        if ($age === null) {
            return null;
        }

        // Staff-configurable via Settings -> Profiling (Age & Status Categories);
        // falls back to the original fixed bands if none are configured yet.
        $bracket = AgeBracket::resolveForAge($age);
        if ($bracket) {
            return $bracket->label;
        }

        if ($age < 13) return 'Child';
        if ($age < 18) return 'Youth';
        if ($age < 60) return 'Adult';
        return 'Senior Citizen';
    }

    /**
     * Adviser example (Senior Citizen eligibility) extended to a
     * Staff-configurable civil status list (Single/Married/Widowed/
     * Separated -- mutually exclusive marital facts).
     */
    public function civilStatus()
    {
        return $this->belongsTo(CivilStatus::class);
    }

    public function getCivilStatusAttribute(): ?string
    {
        // Use getRelationValue() (not $this->civilStatus) to avoid Eloquent's
        // studly-case collision between the "civilStatus" relation and this
        // "civil_status" accessor, which would otherwise recurse infinitely.
        return $this->getRelationValue('civilStatus')?->label;
    }

    /**
     * Staff-configurable "current status" tags (Solo Parent, PWD,
     * Indigent, and similar social/economic categories) -- deliberately
     * separate from civil status, and many-to-many rather than a single
     * column, since these aren't mutually exclusive: a resident can be,
     * say, both a Solo Parent and PWD at once.
     */
    public function currentStatuses()
    {
        return $this->belongsToMany(CurrentStatus::class, 'current_status_user')->orderBy('sort_order');
    }

    public function getCurrentStatusesAttribute(): array
    {
        // Use getRelationValue() (not $this->currentStatuses) to avoid the
        // same accessor/relation name collision guarded against above.
        return $this->getRelationValue('currentStatuses')
            ->map(fn (CurrentStatus $status) => ['id' => $status->id, 'label' => $status->label])
            ->values()
            ->all();
    }
}
