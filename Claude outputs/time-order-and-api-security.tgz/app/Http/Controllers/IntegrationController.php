<?php

namespace App\Http\Controllers;

use App\Services\FacebookService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class IntegrationController extends Controller
{
    // Adviser recommendation: "2 in 1 — Facebook Page (Developer Portal / API)"
    public function facebookStatus(FacebookService $fb)
    {
        if (!$this->isStaff()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        return response()->json($fb->status());
    }

    public function connectFacebook(Request $request, FacebookService $fb)
    {
        if (!$this->isStaff()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $request->validate([
            'page_id' => 'required|string|max:100',
            'access_token' => 'required|string',
        ]);

        $fb->connect($request->page_id, $request->access_token);

        return response()->json(['message' => 'Facebook Page connected.', 'status' => $fb->status()]);
    }

    public function disconnectFacebook(FacebookService $fb)
    {
        if (!$this->isStaff()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $fb->disconnect();

        return response()->json(['message' => 'Facebook Page disconnected.']);
    }

    /**
     * Facebook Messenger webhook verification (GET) — public route, no auth.
     * Register this URL in the Meta Developer Portal along with FACEBOOK_VERIFY_TOKEN.
     */
    public function webhookVerify(Request $request)
    {
        $verifyToken = (string) config('services.facebook.verify_token');

        // Not configured, or a wrong token: refuse. hash_equals keeps the comparison constant-time.
        if ($verifyToken !== ''
            && $request->get('hub_mode') === 'subscribe'
            && hash_equals($verifyToken, (string) $request->get('hub_verify_token'))) {
            return response((string) $request->get('hub_challenge'), 200)->header('Content-Type', 'text/plain');
        }

        return response('Forbidden', 403);
    }

    /**
     * Receives Messenger events (e.g. a resident messaging the Page). Only calls that carry a
     * valid X-Hub-Signature-256 (HMAC of the body with the app secret) are accepted, so a stranger
     * cannot post fake events or fill the log. Only the event type is logged, never the payload.
     * Wire up auto-replies here once a real Page token is set.
     */
    public function webhookReceive(Request $request)
    {
        $secret = (string) config('services.facebook.app_secret');
        $signature = (string) $request->header('X-Hub-Signature-256');
        $expected = 'sha256=' . hash_hmac('sha256', $request->getContent(), $secret);

        if ($secret === '' || !hash_equals($expected, $signature)) {
            return response('Forbidden', 403);
        }

        Log::info('Facebook webhook received', ['object' => (string) $request->input('object')]);

        return response()->json(['status' => 'received']);
    }
}
