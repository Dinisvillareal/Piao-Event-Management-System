<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;
use Tests\Support;
use Tests\TestCase;

/**
 * Hardening found by the API security audit: the Facebook webhook, leftover routes, and
 * "a resident acting on somebody else's record".
 */
class ApiSecurityHardeningTest extends TestCase
{
    use RefreshDatabase, Support;

    protected function setUp(): void
    {
        parent::setUp();
        Cache::flush();
        config(['services.facebook.verify_token' => 'a-long-random-token', 'services.facebook.app_secret' => 'app-secret-123']);
    }

    private function sign(string $body, string $secret = 'app-secret-123'): string
    {
        return 'sha256=' . hash_hmac('sha256', $body, $secret);
    }

    private function hook(string $body, ?string $signature)
    {
        return $this->call('POST', '/integrations/facebook/webhook', [], [], [], array_filter([
            'CONTENT_TYPE' => 'application/json', 'HTTP_X_HUB_SIGNATURE_256' => $signature,
        ]), $body);
    }

    // ---------- Facebook webhook ----------

    public function test_the_webhook_check_needs_the_real_token_and_there_is_no_built_in_one(): void
    {
        $this->get('/integrations/facebook/webhook?hub_mode=subscribe&hub_verify_token=a-long-random-token&hub_challenge=12345')->assertOk()->assertSee('12345');
        $this->get('/integrations/facebook/webhook?hub_mode=subscribe&hub_verify_token=wrong&hub_challenge=12345')->assertStatus(403);
        $this->get('/integrations/facebook/webhook?hub_mode=subscribe&hub_verify_token=piao-verify-token&hub_challenge=12345')->assertStatus(403);   // the old built-in token is gone

        config(['services.facebook.verify_token' => null]);   // not configured -> nothing passes, not even an empty token
        $this->get('/integrations/facebook/webhook?hub_mode=subscribe&hub_verify_token=&hub_challenge=12345')->assertStatus(403);
    }

    public function test_the_webhook_only_accepts_calls_signed_with_the_app_secret(): void
    {
        $body = json_encode(['object' => 'page', 'entry' => [['id' => '1']]]);

        $this->hook($body, $this->sign($body))->assertOk()->assertJson(['status' => 'received']);
        $this->hook($body, null)->assertStatus(403);                                  // no signature
        $this->hook($body, $this->sign($body, 'someone-elses-secret'))->assertStatus(403);   // wrong secret
        $this->hook($body . ' ', $this->sign($body))->assertStatus(403);              // body changed after signing

        config(['services.facebook.app_secret' => null]);   // not configured: refuse everything, even an "empty secret" signature
        $this->hook($body, $this->sign($body, ''))->assertStatus(403);
    }

    public function test_the_webhook_does_not_write_the_payload_to_the_log(): void
    {
        Log::spy();
        $body = json_encode(['object' => 'page', 'message' => 'SECRET-TEXT-FROM-A-RESIDENT']);

        $this->hook($body, $this->sign($body))->assertOk();

        Log::shouldHaveReceived('info')->withArgs(fn ($message, $context = []) => $message === 'Facebook webhook received' && !str_contains(json_encode($context), 'SECRET-TEXT'))->once();
    }

    // ---------- leftover routes ----------

    public function test_no_html_form_pages_and_no_built_in_file_route_are_left_in_the_json_api(): void
    {
        $staff = $this->staff();
        $this->actingAs($staff)->getJson('/api/memberships/create')->assertStatus(404);   // "create" is not an id and there is no form page
        $this->assertFalse(collect(Route::getRoutes())->contains(fn ($r) => str_starts_with($r->uri(), 'storage/{path}')), 'Laravel built-in private file route is still on');
    }

    // ---------- a resident acting on somebody else ----------

    public function test_a_resident_is_refused_on_every_route_that_takes_another_persons_id(): void
    {
        $this->withoutMiddleware(\Illuminate\Routing\Middleware\ThrottleRequests::class);
        $resident = $this->makeUser('Resident');
        $other = $this->makeUser('Resident');

        // the only signed-in routes a resident may use with nothing but their own session (their own data, or lists everyone needs)
        $own = ['/age-brackets', '/api/memberships', '/barangay-officials', '/civil-statuses', '/current-statuses', '/feedback/absence/mine', '/feedback/mine',
            '/feedback/pending', '/me', '/name-suffixes', '/notifications', '/notifications/replies', '/notifications/this-week', '/notifications/unread-count',
            '/settings/feedback-rules', '/logout', '/session/keepalive', '/notifications/read-all', '/notifications/replies-read', '/events-data'];
        // resident actions that are validated first and judged on whose record it is inside the controller
        $residentForms = ['/feedback', '/feedback/' . $other->id];   // PUT /feedback/{event} always writes the signed-in person's own rating

        $checked = 0;
        $bad = [];
        foreach (Route::getRoutes() as $r) {
            $mw = array_map(fn ($m) => class_basename(explode(':', $m)[0]), $r->gatherMiddleware());
            if (!in_array('auth', $mw, true) || in_array('EnsureStaff', $mw, true) || in_array('EnsureHeadStaff', $mw, true)) {
                continue;
            }
            $uri = '/' . ltrim(preg_replace(['/\{kind\}/', '/\{[^}]+\}/'], ['rating', (string) $other->id], $r->uri()), '/');
            if (in_array($uri, $own, true) || in_array($uri, $residentForms, true)) {
                continue;
            }
            foreach ($r->methods() as $method) {
                if ($method === 'HEAD') {
                    continue;
                }
                $status = $this->actingAs($resident)->json($method, $uri, [])->getStatusCode();
                $checked++;
                if (!in_array($status, [403, 404, 405], true)) {
                    $bad[] = "{$method} {$uri} -> {$status}";
                }
            }
        }

        $this->assertGreaterThan(40, $checked);
        $this->assertSame([], $bad, 'routes where a resident acting on another person got through');
    }

    public function test_a_resident_gets_a_plain_refusal_not_the_form_rules_when_registering_someone(): void
    {
        $resident = $this->makeUser('Resident');

        $this->actingAs($resident)->postJson('/users', [])->assertStatus(403)->assertJson(['message' => 'Unauthorized']);   // not a 422 listing the fields
    }
}
