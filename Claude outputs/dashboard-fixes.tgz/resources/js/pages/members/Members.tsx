//LAST WORKING IMPLEMENTATION
// import { useEffect, useMemo, useState } from "react";
// import Sidebar from "../../components/layout/Sidebar";
import { highlightMatches } from "../../lib/highlight";
// import TopHeader from "../../components/layout/TopHeader";
// import SettingsView from "./views/SettingsView";
// import DashboardView from "./views/DashboardView";
// import QRCodesView from "./views/QRCodesView";
// import AttendanceView, { AttendanceRecord } from "./views/AttendanceView";
// import NotificationsView from "./views/NotificationsView";
// import EventsView from "./views/EventsView";
// import OfflineBanner from "../../components/ui/OfflineBanner";
// import FeedbackPrompt from "../../components/ui/FeedbackPrompt";
// import Skeleton from "../../components/ui/Skeleton";
// import api from "../../lib/api";
import { useLanguage } from "../../i18n/LanguageContext";

// Real page title / subtitle shown above the loading skeleton (keys into the i18n table).
const PAGE_HEADINGS: Record<string, [string, string]> = {
  qr: ["myQrAndMemberships", "qrPageSubtitle"],
  attendance: ["attendanceRecords", "attendanceSubtitle"],
  events: ["eventsAndAttendance", "eventsSubtitle"],
  notify: ["notify", "notificationsSubtitle"],
  settings: ["settings", "memberSettingsSubtitle"],
};

// export default function MemberDashboard() {
//   const currentPath = window.location.pathname.replace('/', '');
//   const [active, setActiveState] = useState(currentPath || "dashboard");
//   const [member, setMember] = useState({
//     id: "",
//     name: "",
//     first_name: "",
//     last_name: "",
//     user_code: ""
//   });
//   const [loading, setLoading] = useState(true);
//   const [memberships, setMemberships] = useState([]);
//   const [userMemberships, setUserMemberships] = useState<any[]>([]);
//   const [userMembershipsCount, setUserMembershipsCount] = useState(0);
//   const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
//   const [myFeedback, setMyFeedback] = useState<{ id: number; event_id: number; rating: number; comment: string | null; staff_liked_at?: string | null; staff_reply?: string | null; staff_replied_at?: string | null }[]>([]);
//   const [attended, setAttended] = useState(0);
//   const [missed, setMissed] = useState(0);
//   const [upcomingEvents, setUpcomingEvents] = useState<any[]>([]);
//   const [pastEvents, setPastEvents] = useState<any[]>([]);
//   const [notifications, setNotifications] = useState<any[]>([]);
//   const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

//   const parseApiDate = (value: string) => {
//     if (!value) return new Date(0);
//     return new Date(value.replace(" ", "T"));
//   };

//   const allEvents = useMemo(() => [
//     ...(Array.isArray(upcomingEvents) ? upcomingEvents : []),
//     ...(Array.isArray(pastEvents) ? pastEvents : [])
//   ], [upcomingEvents, pastEvents]);

//   // Helper function to safely parse JSON responses
//   const safeJsonParse = async (response: Response) => {
//     const contentType = response.headers.get("content-type");
//     if (!contentType || !contentType.includes("application/json")) {
//       console.error("Expected JSON but got:", contentType);
//       throw new Error("Server returned HTML instead of JSON");
//     }
//     return response.json();
//   };

//   // Fetch notifications function (reusable)
//   const fetchNotifications = async () => {
//     try {
//       const response = await api.get('/notifications');
//       const data = response.data;
//       {
//         const notificationsData = data.data || data || [];
//         setNotifications(notificationsData.map((notification: any) => ({
//           id: notification.id,
//           title: notification.title,
//           message: notification.message || notification.body,
//           created_at: notification.created_at,
//           is_updated: notification.is_updated,
//           read: notification.read || false,
//           updated_at_notification: notification.updated_at_notification,
//         })));
//       }
//     } catch (error) {
//       console.error('Failed to fetch notifications:', error);
//     }
//   };

//   // ─── POPSTATE (browser back/forward) ────────────────────────────────────────
//   useEffect(() => {
//     const handlePopState = () => {
//       const path = window.location.pathname.replace('/', '') || "dashboard";
//       setActiveState(path);
//     };
//     window.addEventListener("popstate", handlePopState);
//     return () => window.removeEventListener("popstate", handlePopState);
//   }, []);

//   // ─── REFETCH NOTIFICATIONS WHEN RETURNING TO DASHBOARD ───────────────────────
//   useEffect(() => {
//     if (active === "dashboard") {
//       fetchNotifications();
//     }
//   }, [active]);

//   // ─── LIVE NOTIFICATION POLLING (Notifications page) ─────────────────────────
//   // Quietly re-checks for new notifications every 20s while the member is on
//   // the Notifications page -- the Dashboard's own notification refresh is
//   // folded into the broader "LIVE DASHBOARD POLLING" effect further down, so
//   // it doesn't run twice while the member is on the Dashboard.
//   useEffect(() => {
//     if (active !== "notify") return;
//     const poll = setInterval(fetchNotifications, 20000);
//     return () => clearInterval(poll);
//   }, [active]);

//   // ─── FETCH LOGGED-IN USER ────────────────────────────────────────────────────
//   useEffect(() => {
//     api.get('/me')
//       .then((res) => {
//         const user = res.data;
//         setMember({
//           id: user.id,
//           name: `${user.first_name} ${user.last_name}`,
//           first_name: user.first_name,
//           last_name: user.last_name,
//           user_code: user.user_code || ''
//         });
//       })
//       .catch((err) => {
//         // The shared axios instance already redirects to "/" on 401/419.
//         console.error("Failed to fetch user:", err);
//       })
//       .finally(() => {
//         setLoading(false);
//       });
//   }, []);

//   // ─── FETCH ALL MEMBERSHIP TYPES (for QR Codes view) ─────────────────────────
//   useEffect(() => {
//     api.get('/api/memberships')
//       .then((res) => {
//         const data = res.data;
//         setMemberships(data.data || data || []);
//       })
//       .catch(err => {
//         console.error('Failed to fetch memberships:', err);
//         setMemberships([]);
//       });
//   }, []);

//   // Fetch events function (reusable -- also re-run by the live dashboard poll below)
//   const fetchEvents = async () => {
//     // ✅ NEW: Get portal mode from storage
//     const portalMode = localStorage.getItem("portalMode") || sessionStorage.getItem("portalMode") || "member";

//     try {
//       const res = await api.get('/events-data', { headers: { 'X-Portal-Mode': portalMode } });
//       const data = res.data;
//       if (!data?.data) {
//         console.error('No events returned:', data);
//         return;
//       }

//       const now = new Date();

//       const formattedEvents = data.data.map((event: any) => ({
//         id: event.id,
//         title: event.name,
//         date: event.event_start,
//         event_start: event.event_start,
//         event_end: event.event_end,
//         location: event.location,
//         description: event.description,
//         membership_ids: Array.isArray(event.membership_ids) ? event.membership_ids : [],
//         memberships: Array.isArray(event.memberships) ? event.memberships : [],
//         notificationMessage: event.notification_message,
//         membershipNames: event.memberships?.map((m: any) => m.name) || [],
//         startDate: event.event_start?.split(" ")[0],
//         startTime: new Date(event.event_start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
//       }));

//       const upcoming = formattedEvents.filter((e: any) => parseApiDate(e.date) >= now);
//       const past = formattedEvents.filter((e: any) => parseApiDate(e.date) < now);

//       setUpcomingEvents(upcoming);
//       setPastEvents(past);
//     } catch (err) {
//       console.error('Failed to fetch events:', err);
//     }
//   };

//   // Fetch the signed-in member's own membership count (reusable)
//   const fetchUserMembershipsCount = async (memberId: string) => {
//     try {
//       const res = await api.get(`/membership-residents/${memberId}`, { params: { per_page: 100 } });
//       const data = res.data;
//       setUserMembershipsCount(data.total || data.memberships?.length || 0);
//       setUserMemberships(Array.isArray(data.memberships) ? data.memberships : []);
//     } catch (err) {
//       console.error('Failed to fetch user memberships count:', err);
//     }
//   };

//   // Fetch the signed-in member's attendance records (reusable)
//   const fetchAttendanceRecords = async (memberId: string) => {
//     try {
//       const res = await api.get(`/attendance/${memberId}`);
//       const data = res.data;
//       if (!Array.isArray(data)) return;

//       const records: AttendanceRecord[] = data.map((item: any) => ({
//         id: item.id,
//         eventId: item.eventId,
//         eventTitle: item.eventTitle ?? '—',      // ✅ Direct property
//         eventDate: item.eventDate ?? '',          // ✅ Direct property
//         location: item.location ?? '—',           // ✅ Direct property
//         timeIn: item.timeIn ?? '',
//         timeOut: item.timeOut ?? '',
//         status: (!item.timeIn && !item.timeOut) ? 'missed' : (item.status?.toLowerCase() ?? 'incomplete'),
//       }));

//       const attendedCount = records.filter(r => r.status === 'complete').length;
//       const missedCount = records.filter(r => r.status === 'missed').length;

//       setAttendanceRecords(records);
//       setAttended(attendedCount);
//       setMissed(missedCount);

//       sessionStorage.setItem(`attendance_cache_${memberId}`, JSON.stringify({
//         records: records,
//         attended: attendedCount,
//         missed: missedCount
//       }));
//     } catch (err) {
//       console.error('Failed to fetch attendance:', err);
//     }
//   };

//   // ─── FETCH EVENTS (initial) ──────────────────────────────────────────────────
//   useEffect(() => {
//     fetchEvents();
//   }, []);

//   // ─── FETCH NOTIFICATIONS (initial) ──────────────────────────────────────────
//   useEffect(() => {
//     fetchNotifications();
//   }, []);

//   // ─── FETCH USER'S MEMBERSHIP COUNT (initial) ────────────────────────────────
//   useEffect(() => {
//     if (!member.id) return;
//     fetchUserMembershipsCount(member.id);
//   }, [member.id]);

//   // ─── FETCH ATTENDANCE RECORDS (initial, seeded from session cache first) ────
//   useEffect(() => {
//     if (!member.id) return;

//     const cacheKey = `attendance_cache_${member.id}`;
//     const cachedData = sessionStorage.getItem(cacheKey);
//     if (cachedData) {
//       const parsedData = JSON.parse(cachedData);
//       setAttendanceRecords(parsedData.records);
//       setAttended(parsedData.attended);
//       setMissed(parsedData.missed);
//     }

//     fetchAttendanceRecords(member.id);
//   }, [member.id]);

//   // ─── LIVE DASHBOARD POLLING ──────────────────────────────────────────────────
//   // Keeps the *whole* Dashboard live, not just notifications: while the member
//   // is on the Dashboard, notifications, the events list, membership count and
//   // attendance/check-ins are all quietly re-fetched every 20s, so every number
//   // and card on the page moves on its own -- no manual refresh, no need to
//   // leave and come back -- mirroring the staff portal's own live dashboards.
//   useEffect(() => {
//     if (active !== "dashboard") return;
//     const poll = setInterval(() => {
//       fetchNotifications();
//       fetchEvents();
//       if (member.id) {
//         fetchUserMembershipsCount(member.id);
//         fetchAttendanceRecords(member.id);
//       }
//     }, 20000);
//     return () => clearInterval(poll);
//   }, [active, member.id]);

//   // ─── FETCH MY OWN EVENT FEEDBACK (drives the reviews module on Events) ─────
//   useEffect(() => {
//     if (!member.id) return;

//     api.get('/feedback/mine')
//       .then((res) => setMyFeedback(Array.isArray(res.data) ? res.data : []))
//       .catch((err) => console.error('Failed to fetch my feedback:', err));
//   }, [member.id]);

//   // ─── NAVIGATION ────────────────────────────────────────────────────────────
//   const setActive = (page: string) => {
//     const url = page === "dashboard" ? "/" : `/${page}`;
//     window.history.pushState({}, "", url);
//     setActiveState(page);
//   };

//   // ─── HIGHLIGHT MATCHED SEARCH TEXT ───────────────────────────────────────────
//   const highlightText = (text: string, query: string) => highlightMatches(text, query);

//   // ─── LOADING SCREEN ───────────────────────────────────────────────────────────
//   if (loading) {
//     // Generic dashboard-shell skeleton (header + a KPI strip + a content
//     // block) -- the actual layout isn't known yet at this point (still
//     // waiting to hear back who's signed in), so this is a reasonable
//     // stand-in shape rather than an exact match of any one page.
//     return (
//       <div className="min-h-screen bg-[#0A0E1A] p-6 sm:p-10">
//         <div className="mx-auto max-w-5xl space-y-8">
//           <div className="flex items-center gap-4">
//             <Skeleton className="h-12 w-12 rounded-full" />
//             <div className="space-y-2">
//               <Skeleton className="h-4 w-40" />
//               <Skeleton className="h-3 w-28" />
//             </div>
//           </div>
//           <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
//             {Array.from({ length: 4 }).map((_, i) => (
//               <Skeleton key={i} className="h-24 rounded-2xl" />
//             ))}
//           </div>
//           <Skeleton className="h-64 rounded-2xl" />
//         </div>
//       </div>
//     );
//   }

//   // ─── RENDER ──────────────────────────────────────────────────────────────────
//   return (
//     <div className="min-h-screen bg-[#0A0E1A] text-white">
//       <div className="flex min-h-screen">
//         <Sidebar
//           active={active}
//           setActive={setActive}
//           mobileOpen={mobileSidebarOpen}
//           onCloseMobile={() => setMobileSidebarOpen(false)}
//         />

//         <main className="flex-1 min-w-0">
//           <TopHeader memberName={member.name} onMenuClick={() => setMobileSidebarOpen(true)} userId={member.id} />
//           <OfflineBanner />
//           <FeedbackPrompt />

//           <div
//             className="h-[calc(100dvh-73px)] overflow-y-auto smooth-scroll"
//             style={{ scrollBehavior: 'smooth', scrollbarGutter: 'stable' }}
//           >
//             <div className="space-y-5 p-3 sm:p-5">

//               {/* DASHBOARD */}
//               {active === "dashboard" && (
//                 <DashboardView
//                   memberName={member.first_name}
//                   fullName={member.name}
//                   userId={member.id}
//                   userCode={member.user_code}
//                   membershipsCount={userMembershipsCount}
//                   attendedCount={attended}
//                   missedCount={missed}
//                   attendanceRecords={attendanceRecords}
//                   setActive={setActive}
//                   notifications={notifications}
//                   upcomingEvents={upcomingEvents}
//                   pastEventsCount={pastEvents.length}
//                   highlightText={highlightText}
//                 />
//               )}

//               {/* MY QR CODES */}
//               {active === "qr" && (
//                 <QRCodesView
//                   highlightText={highlightText}
//                   userId={member.id}
//                   userCode={member.user_code}
//                   fullName={member.name}
//                 />
//               )}

//               {/* ATTENDANCE */}
//               {active === "attendance" && (
//                 <AttendanceView
//                   attendanceRecords={attendanceRecords}
//                   highlightText={highlightText}
//                   allEvents={allEvents}
//                   userMemberships={userMemberships}
//                 />
//               )}

//               {/* EVENTS */}
//               {active === "events" && (
//                 <EventsView
//                   allEvents={allEvents}
//                   highlightText={highlightText}
//                   allMemberships={memberships}
//                   userMemberships={userMemberships}
//                   attendanceRecords={attendanceRecords}
//                   myFeedback={myFeedback}
//                   onFeedbackSubmitted={(entry) =>
//                     setMyFeedback((prev) => {
//                       const rest = prev.filter((f) => f.event_id !== entry.event_id);
//                       return [...rest, entry];
//                     })
//                   }
//                 />
//               )}

//               {/* NOTIFICATIONS */}
//               {active === "notify" && (
//                 <NotificationsView
//                   highlightText={highlightText}
//                 />
//               )}

//               {/* SETTINGS */}
//               {active === "settings" && (
//                 <SettingsView member={member} />
//               )}

//             </div>
//           </div>
//         </main>
//       </div>

//       <style>{`
//         .smooth-scroll {
//           scroll-behavior: smooth !important;
//           -webkit-overflow-scrolling: touch;
//         }
//         .smooth-scroll::-webkit-scrollbar {
//           width: 6px;
//           height: 6px;
//         }
//         .smooth-scroll::-webkit-scrollbar-track {
//           background: #f1f1f1;
//           border-radius: 10px;
//         }
//         .smooth-scroll::-webkit-scrollbar-thumb {
//           background: #ccc;
//           border-radius: 10px;
//         }
//         .smooth-scroll::-webkit-scrollbar-thumb:hover {
//           background: #aaa;
//         }
//         .shadow-b-sm {
//           box-shadow: 0 2px 4px rgba(0,0,0,0.05);
//         }
//       `}</style>
//     </div>
//   );
// }

//LAST WORKING IMPLEMENTATION
import { useEffect, useMemo, useRef, useState } from "react";
import Sidebar from "../../components/layout/Sidebar";
import TopHeader from "../../components/layout/TopHeader";
import SettingsView from "./views/SettingsView";
import DashboardView, { MemberDashboardSkeleton } from "./views/DashboardView";
import QRCodesView from "./views/QRCodesView";
import AttendanceView, { AttendanceRecord } from "./views/AttendanceView";
import NotificationsView from "./views/NotificationsView";
import EventsView from "./views/EventsView";
import MemberReplyAlerts from "../../components/ui/MemberReplyAlerts";
import type { AbsenceEntry } from "./views/EventsView";
import OfflineBanner from "../../components/ui/OfflineBanner";
import FeedbackPrompt from "../../components/ui/FeedbackPrompt";
import Skeleton from "../../components/ui/Skeleton";
import api from "../../lib/api";
import { memberKeyFromPath, memberUrlFor } from "../../lib/memberRoutes";
import { attendanceStatus } from "../../lib/attendanceStatus";
import { useThemeScope } from "../../lib/theme";
import { useFeedHealth, useVisiblePoll } from "../../hooks/useLiveFeeds";

export default function MemberDashboard() {
  const { t } = useLanguage();
  useThemeScope();
  const [active, setActiveState] = useState(() => memberKeyFromPath(window.location.pathname));
  const [member, setMember] = useState({
    id: "",
    name: "",
    // Last known first name, so the dashboard headline reads "Welcome back, Ana"
    // even during the first moments before the account call returns.
    first_name: (() => { try { return localStorage.getItem("member_first_name") || ""; } catch { return ""; } })(),
    last_name: "",
    user_code: ""
  });
  const [loading, setLoading] = useState(true);
  // Which dashboard feeds failed on their last try (kept data stays on screen; the dashboard says so).
  const { failedCount, lastOkAt, report, completeCycle } = useFeedHealth();
  const [retryingFeeds, setRetryingFeeds] = useState(false);
  const [memberships, setMemberships] = useState([]);
  const [userMemberships, setUserMemberships] = useState<any[]>([]);
  const [userMembershipsCount, setUserMembershipsCount] = useState(0);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [myFeedback, setMyFeedback] = useState<{ id: number; event_id: number; rating: number; comment: string | null; staff_liked_at?: string | null; staff_reply?: string | null; staff_replied_at?: string | null; edit_until?: number }[]>([]);
  const [myAbsences, setMyAbsences] = useState<AbsenceEntry[]>([]);
  const [focusEventId, setFocusEventId] = useState<number | null>(null);
  const [feedbackRules, setFeedbackRules] = useState({ close_after_hours: 12, edit_window_minutes: 30 });
  const [replyUnread, setReplyUnread] = useState(0);
  const [attended, setAttended] = useState(0);
  const [missed, setMissed] = useState(0);
  // Missed = no sign-in for an event that has already ENDED (upcoming / ongoing events don't count).
  const missedNow = useMemo(() => attendanceRecords.filter((r) => attendanceStatus(r) === 'missed').length, [attendanceRecords]);
  const [upcomingEvents, setUpcomingEvents] = useState<any[]>([]);
  const [pastEvents, setPastEvents] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  // First-load flags for the data-driven pages, so each page can show its own
  // skeleton (like the staff pages) instead of flashing empty states / zeros.
  const [eventsLoading, setEventsLoading] = useState(true);
  const [attendanceLoading, setAttendanceLoading] = useState(true);

  const parseApiDate = (value: string) => {
    if (!value) return new Date(0);
    return new Date(value.replace(" ", "T"));
  };

  const allEvents = useMemo(() => [
    ...(Array.isArray(upcomingEvents) ? upcomingEvents : []),
    ...(Array.isArray(pastEvents) ? pastEvents : [])
  ], [upcomingEvents, pastEvents]);

  const fetchNotifications = async () => {
    try {
      const response = await api.get('/notifications');
      const data = response.data;
      const notificationsData = data.data || data || [];
      setNotifications(notificationsData.map((notification: any) => ({
        id: notification.id,
        title: notification.title,
        message: notification.message || notification.body,
        created_at: notification.created_at,
        is_updated: notification.is_updated,
        read: notification.read || false,
        updated_at_notification: notification.updated_at_notification,
      })));
      report('notifications', true);
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
      report('notifications', false);
    }
  };

  useEffect(() => {
    const handlePopState = () => {
      setActiveState(memberKeyFromPath(window.location.pathname));
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  useEffect(() => {
    if (active === "dashboard") fetchNotifications();
  }, [active]);

  // Re-checks every 20s while the Notifications page is open -- paused while the tab is hidden.
  useVisiblePoll(() => { void fetchNotifications(); }, 20000, active === "notify");

  // Keeps the sidebar's unread badge live on every page: loads once, re-checks
  // every 20s, and refreshes right away when the Notifications page marks
  // something read (it fires "member-notifications-changed").
  // The badge number comes from the server's own unread count. Counting rows of
  // GET /notifications is wrong: that endpoint is paginated (unread first), so the
  // count was capped at one page and, after reading some, the next unread rows slid
  // in and the badge never went down.
  const [unreadNotificationCount, setUnreadNotificationCount] = useState(0);
  const fetchUnreadCount = async () => {
    try {
      const res = await api.get('/notifications/unread-count');
      setUnreadNotificationCount(Number(res.data?.count) || 0);
      report('unread', true);
    } catch (error) {
      console.error('Failed to fetch unread count:', error);
      report('unread', false);
    }
  };

  useEffect(() => {
    fetchNotifications();
    fetchUnreadCount();
    const onChanged = () => { fetchNotifications(); fetchUnreadCount(); };
    window.addEventListener("member-notifications-changed", onChanged);
    return () => window.removeEventListener("member-notifications-changed", onChanged);
  }, []);

  // The sidebar badge re-checks every 20s -- paused while the tab is hidden, and refreshed
  // straight away when the tab comes back to the front.
  useVisiblePoll(() => { void fetchNotifications(); void fetchUnreadCount(); }, 20000);

  useEffect(() => {
    api.get('/me')
      .then((res) => {
        const user = res.data;
        try { localStorage.setItem("member_first_name", user.first_name || ""); } catch { /* storage unavailable */ }
        setMember({
          id: user.id,
          name: `${user.first_name} ${user.last_name}${user.suffix ? `, ${user.suffix}` : ''}`,
          first_name: user.first_name,
          last_name: user.last_name,
          user_code: user.user_code || ''
        });
      })
      .catch((err) => console.error("Failed to fetch user:", err))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    api.get('/api/memberships')
      .then((res) => {
        const data = res.data;
        setMemberships(data.data || data || []);
      })
      .catch(err => {
        console.error('Failed to fetch memberships:', err);
        setMemberships([]);
      });
  }, []);

  const fetchEvents = async () => {
    const portalMode = localStorage.getItem("portalMode") || sessionStorage.getItem("portalMode") || "member";
    try {
      const res = await api.get('/events-data', { headers: { 'X-Portal-Mode': portalMode } });
      const data = res.data;
      if (!data?.data) return;
      const now = new Date();
      const formattedEvents = data.data.map((event: any) => ({
        id: event.id,
        title: event.name,
        date: event.event_start,
        event_start: event.event_start,
        event_end: event.event_end,
        location: event.location,
        description: event.description,
        membership_ids: Array.isArray(event.membership_ids) ? event.membership_ids : [],
        memberships: Array.isArray(event.memberships) ? event.memberships : [],
        notificationMessage: event.notification_message,
        membershipNames: event.memberships?.map((m: any) => m.name) || [],
        startDate: event.event_start?.split(" ")[0],
        startTime: new Date(event.event_start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }));
      setUpcomingEvents(formattedEvents.filter((e: any) => parseApiDate(e.date) >= now));
      setPastEvents(formattedEvents.filter((e: any) => parseApiDate(e.date) < now));
      report('events', true);
    } catch (err) {
      console.error('Failed to fetch events:', err);
      report('events', false);
    } finally {
      setEventsLoading(false);
    }
  };

  const fetchUserMembershipsCount = async (memberId: string) => {
    try {
      const res = await api.get(`/membership-residents/${memberId}`, { params: { per_page: 100 } });
      const data = res.data;
      setUserMembershipsCount(data.total || data.memberships?.length || 0);
      setUserMemberships(Array.isArray(data.memberships) ? data.memberships : []);
      report('memberships', true);
    } catch (err) {
      console.error('Failed to fetch user memberships count:', err);
      report('memberships', false);
    }
  };

  const fetchAttendanceRecords = async (memberId: string) => {
    try {
      const res = await api.get(`/attendance/${memberId}`);
      const data = res.data;
      if (!Array.isArray(data)) return;
      const records: AttendanceRecord[] = data.map((item: any) => ({
        id: item.id,
        eventId: item.eventId,
        eventTitle: item.eventTitle ?? '—',
        eventDate: item.eventDate ?? '',
        eventEnd: item.eventEnd ?? '',
        location: item.location ?? '—',
        timeIn: item.timeIn ?? '',
        timeOut: item.timeOut ?? '',
        status: (!item.timeIn && !item.timeOut) ? 'missed' : (item.status?.toLowerCase() ?? 'incomplete'),
      }));
      const attendedCount = records.filter(r => r.status === 'complete').length;
      const missedCount = records.filter(r => attendanceStatus(r) === 'missed').length;
      setAttendanceRecords(records);
      setAttended(attendedCount);
      setMissed(missedCount);
      sessionStorage.setItem(`attendance_cache_${memberId}`, JSON.stringify({
        records, attended: attendedCount, missed: missedCount
      }));
      report('attendance', true);
    } catch (err) {
      console.error('Failed to fetch attendance:', err);
      report('attendance', false);
    } finally {
      setAttendanceLoading(false);
    }
  };

  useEffect(() => { fetchEvents(); }, []);
  useEffect(() => { fetchNotifications(); }, []);

  useEffect(() => {
    if (!member.id) return;
    fetchUserMembershipsCount(member.id);
  }, [member.id]);

  useEffect(() => {
    if (!member.id) return;
    const cacheKey = `attendance_cache_${member.id}`;
    const cachedData = sessionStorage.getItem(cacheKey);
    if (cachedData) {
      const parsedData = JSON.parse(cachedData);
      setAttendanceRecords(parsedData.records);
      setAttended(parsedData.attended);
      setMissed(parsedData.missed);
      setAttendanceLoading(false); // cached copy is good enough to show right away
    }
    fetchAttendanceRecords(member.id);
  }, [member.id]);

  // One refresh of everything the dashboard shows. "Last updated" only moves forward when
  // every feed answered, so the page never looks fresh while part of it is stale.
  const refreshDashboard = async () => {
    await Promise.all([
      fetchNotifications(),
      fetchEvents(),
      member.id ? fetchUserMembershipsCount(member.id) : Promise.resolve(),
      member.id ? fetchAttendanceRecords(member.id) : Promise.resolve(),
    ]);
    completeCycle();
  };

  // Every 20s while the dashboard is open -- paused while the tab is hidden, and run
  // straight away when it is shown again or the connection comes back.
  useVisiblePoll(() => { void refreshDashboard(); }, 20000, active === "dashboard");

  const retryDashboard = async () => {
    setRetryingFeeds(true);
    try { await refreshDashboard(); } finally { setRetryingFeeds(false); }
  };

  useEffect(() => {
    if (!member.id) return;
    // Re-read whenever the Events page is opened or staff respond, so a heart or reply shows up.
    const load = () => {
      api.get('/feedback/mine')
        .then((res) => setMyFeedback(Array.isArray(res.data) ? res.data.map((f: any) => ({ ...f, edit_until: Date.now() + (Number(f.edit_seconds_left) || 0) * 1000 })) : []))
        .catch((err) => console.error('Failed to fetch my feedback:', err));
      api.get('/feedback/absence/mine')
        .then((res) => setMyAbsences(Array.isArray(res.data) ? res.data.map((r: any) => ({ ...r, edit_until: Date.now() + (Number(r.edit_seconds_left) || 0) * 1000 })) : []))
        .catch((err) => console.error('Failed to fetch my absence reasons:', err));
      api.get('/settings/feedback-rules')
        .then((res) => { if (res.data?.close_after_hours) setFeedbackRules(res.data); })
        .catch(() => {});
    };
    load();
    window.addEventListener("member:feedback-responded", load);
    return () => window.removeEventListener("member:feedback-responded", load);
  }, [member.id, active === "events"]); // eslint-disable-line react-hooks/exhaustive-deps

  // Other parts of the portal (e.g. a notification card) ask to jump to a page.
  useEffect(() => {
    const go = (e: Event) => {
      const page = (e as CustomEvent).detail?.page;
      const eventId = (e as CustomEvent).detail?.eventId;
      if (page === "events" && typeof eventId === "number") setFocusEventId(eventId);
      if (typeof page === "string") setActiveRef.current(page);
    };
    window.addEventListener("member:open-page", go);
    return () => window.removeEventListener("member:open-page", go);
  }, []);

  // Data pages (Dashboard / Attendance / Events) read from state that is kept
  // in this component, so re-opening them would otherwise appear instantly with
  // no loading state. Like the staff pages, every visit shows the page's
  // skeleton briefly while the data is quietly refreshed.
  const [navSwitching, setNavSwitching] = useState(false);
  const navTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const setActive = (page: string) => {
    window.history.pushState({}, "", memberUrlFor(page));
    if (["dashboard", "attendance", "events"].includes(page)) {
      setNavSwitching(true);
      if (navTimer.current) clearTimeout(navTimer.current);
      navTimer.current = setTimeout(() => setNavSwitching(false), 450);
      fetchEvents();
      if (member.id) fetchAttendanceRecords(member.id);
    }
    setActiveState(page);
  };
  // Listeners registered once always call the latest version.
  const setActiveRef = useRef(setActive);
  setActiveRef.current = setActive;

  const highlightText = (text: string, query: string) => {
    if (!query.trim()) return text;
    const regex = new RegExp(`(${query})`, "gi");
    const parts = text.split(regex);
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <mark key={i} className="bg-yellow-300 rounded-sm px-0.5">{part}</mark>
      ) : (part)
    );
  };

  return (
    <div className="min-h-screen bg-[#0A0E1A] text-white">
      <div className="flex min-h-screen">
        <Sidebar
          active={active}
          setActive={setActive}
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
          userName={member.name}
          userRole="Member"
          badges={{ notify: unreadNotificationCount, events: replyUnread }}
        />

        <main className="flex-1 min-w-0 flex flex-col">
          <TopHeader memberName={member.name} onMenuClick={() => setMobileSidebarOpen(true)} userId={member.id} onNavigate={setActive} />
          <OfflineBanner />
          <FeedbackPrompt />
          <MemberReplyAlerts active={active} onOpenEvents={(eventId) => { if (typeof eventId === "number") setFocusEventId(eventId); setActive("events"); }} onOpenNotifications={() => setActive("notify")} onUnreadChange={setReplyUnread} />

          {/* ================================================================
              THE ACTUAL FIX:
              The outer wrapper no longer scrolls itself. It just bounds the
              height. Each view below is now the ONLY scroll container, which
              is what allows its flex-shrink-0 header (containing the
              pagination) to stay pinned while only the list scrolls.
              ================================================================ */}
          <div className="h-[calc(100dvh-73px)] overflow-hidden flex-1">
            <div className="h-full">
              {/* Same behaviour as the staff portal: the shell (sidebar +
                  header) is always on screen and only the page body shows a
                  skeleton while the account loads. */}
              {loading && active === "dashboard" && <MemberDashboardSkeleton memberName={member.first_name} />}
              {loading && (active === "qr" || active === "settings") && (
                <div className="h-full overflow-hidden bg-[#0A0E1A] p-4 sm:p-8">
                  <div>
                    <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">{t(PAGE_HEADINGS[active]?.[0] ?? "settings")}</h1>
                    <p className="mt-1.5 text-sm text-white/50 max-w-xl">{t(PAGE_HEADINGS[active]?.[1] ?? "memberSettingsSubtitle")}</p>
                  </div>
                    <div className="mt-6 space-y-3">
                      <Skeleton className="h-16 w-full rounded-2xl" />
                      {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-3xl" />)}
                    </div>
                </div>
              )}
              {!loading && active === "dashboard" && (
                <DashboardView
                  loading={eventsLoading || attendanceLoading || navSwitching}
                  memberName={member.first_name}
                  fullName={member.name}
                  userId={member.id}
                  userCode={member.user_code}
                  membershipsCount={userMembershipsCount}
                  attendedCount={attended}
                  missedCount={missedNow}
                  attendanceRecords={attendanceRecords}
                  setActive={setActive}
                  notifications={notifications}
                  upcomingEvents={upcomingEvents}
                  pastEventsCount={pastEvents.length}
                  highlightText={highlightText}
                  failedFeeds={failedCount}
                  lastUpdatedAt={lastOkAt}
                  onRetryFeeds={retryDashboard}
                  retryingFeeds={retryingFeeds}
                />
              )}

              {!loading && active === "qr" && (
                <QRCodesView
                  highlightText={highlightText}
                  userId={member.id}
                  userCode={member.user_code}
                  fullName={member.name}
                />
              )}

              {active === "attendance" && (
                <AttendanceView
                  loading={attendanceLoading || navSwitching}
                  attendanceRecords={attendanceRecords}
                  memberId={member.id}
                  highlightText={highlightText}
                  allEvents={allEvents}
                  userMemberships={userMemberships}
                />
              )}

              {active === "events" && (
                <EventsView
                  loading={eventsLoading || navSwitching}
                  allEvents={allEvents}
                  highlightText={highlightText}
                  allMemberships={memberships}
                  userMemberships={userMemberships}
                  attendanceRecords={attendanceRecords}
                  myFeedback={myFeedback}
                  myAbsences={myAbsences}
                  focusEventId={focusEventId}
                  member={member}
                  onFocusHandled={() => setFocusEventId(null)}
                  feedbackRules={feedbackRules}
                  onAbsenceSubmitted={(entry) =>
                    setMyAbsences((prev) => [...prev.filter((r) => r.event_id !== entry.event_id), entry])
                  }
                  // onFeedbackSubmitted={(entry) =>
                  //   setMyFeedback((prev) => {
                  //     const rest = prev.filter((f) => f.event_id !== entry.event_id);
                  //     return [...rest, entry];
                  //   })
                  // }

                  onFeedbackSubmitted={(entry) => {
                    setMyFeedback((prev) => {
                      const rest = prev.filter((f) => f.event_id !== entry.event_id);
                      if ((entry as any).deleted_at) {
                        return rest;
                      }
                      return [...rest, entry];
                    });
                  }}
                />
              )}

              {active === "notify" && (
                <NotificationsView highlightText={highlightText} />
              )}

              {!loading && active === "settings" && (
                <SettingsView member={member} />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}