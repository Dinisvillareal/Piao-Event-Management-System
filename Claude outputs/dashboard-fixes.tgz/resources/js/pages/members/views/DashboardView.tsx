import { useClockFormat } from "../../../lib/clockFormat";
import SummaryCard from "../../../components/ui/SummaryCard";
import Skeleton from "../../../components/ui/Skeleton";
import { useEffect, useMemo, useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { Award, CheckCircle2, CalendarDays, Clock, QrCode, ClipboardCheck, Bell as BellIcon, AlertCircle } from "lucide-react";
import type { AttendanceRecord } from "./AttendanceView";
import { useLanguage } from "../../../i18n/LanguageContext";
import { tc } from "../../../lib/contentTranslations";
import FeedWarning from "../../../components/ui/FeedWarning";

interface Notification {
  id: number;
  title: string;
  message: string;
  created_at: string;
  is_updated: boolean;
  read: boolean;
}

interface Event {
  id: number;
  title: string;
  date: string;
  location: string;
  description: string;
}

interface DashboardViewProps {
  memberName: string;
  fullName: string;
  userId: string | number;
  userCode: string;
  membershipsCount: number;
  attendedCount: number;
  missedCount: number;
  attendanceRecords: AttendanceRecord[];
  setActive: (page: string) => void;
  notifications: Notification[];
  upcomingEvents: Event[];
  pastEventsCount: number;
  highlightText: (text: string, query: string) => React.ReactNode;
  /** True until events / attendance first load -- shows the skeleton layout. */
  loading?: boolean;
  /** How many data feeds failed on their last refresh (0 = all good), and the retry for them. */
  failedFeeds?: number;
  lastUpdatedAt?: Date;
  onRetryFeeds?: () => void;
  retryingFeeds?: boolean;
}

/**
 * Page header shared by the loaded dashboard and its skeleton, so the title
 * block never changes (or disappears) while the data underneath loads.
 * Title type matches the staff dashboard's "Welcome back" headline.
 */
function MemberDashboardHeader({ memberName, loading = false }: { memberName: string; loading?: boolean }) {
  const { t } = useLanguage();
  if (loading) {
    return (
      <div>
        <div className="flex items-center gap-2.5">
          <Skeleton className="h-3.5 w-36" />
          <Skeleton className="h-6 w-16 rounded-full" />
        </div>
        <Skeleton className="mt-3 h-9 w-80 max-w-full sm:h-10" />
        <Skeleton className="mt-3 h-4 w-64 max-w-full" />
      </div>
    );
  }
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2.5">
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#7DD8CB]">{t("memberDashboard")}</p>
        {/* "Live" pulse -- the page quietly re-polls every 20s (see Members.tsx). */}
        <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] font-medium text-white/50" title={t("liveLabel")}>
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#4FBEB0] opacity-75" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#4FBEB0]" />
          </span>
          {t("liveLabel")}
        </span>
      </div>
      <h1 className="mt-2 font-display text-3xl font-extrabold text-white sm:text-4xl">
        {t("welcomeBack")}, {memberName}
      </h1>
      <p className="mt-2 max-w-md text-[15px] text-white/55">{t("signedInAsResident")}</p>
    </div>
  );
}

/**
 * Skeleton shaped exactly like the loaded member dashboard: header, three
 * stat cards, "My activity" + QR panels, then the notifications + upcoming
 * events lists. Used both while the account loads and while the first
 * events / attendance fetch lands, so the page never jumps.
 */
export function MemberDashboardSkeleton({ memberName = "" }: { memberName?: string }) {
  const { t } = useLanguage();
  const panel = "rounded-2xl border border-white/10 bg-white/[0.04] p-5";
  return (
    <div className="h-[calc(100dvh-73px)] overflow-y-auto bg-[#0A0E1A] p-4 sm:p-8">
      <div className="space-y-5">
        <MemberDashboardHeader memberName={memberName} loading />

        {/* Summary cards */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-36 rounded-3xl" />
          ))}
        </div>

        {/* My activity + QR */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
          <div className={`${panel} space-y-4`}>
            <div className="flex items-center justify-between">
              <Skeleton className="h-6 w-40" />
              <Skeleton className="h-9 w-36 rounded-xl" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))}
            </div>
          </div>
          <div className={`${panel} space-y-4`}>
            <div className="flex items-center gap-3">
              <Skeleton className="h-10 w-10 rounded-xl" />
              <Skeleton className="h-6 w-32" />
            </div>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Skeleton className="h-[166px] w-[166px] shrink-0 rounded-xl" />
              <div className="flex-1 space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-11 w-44 rounded-full" />
              </div>
            </div>
          </div>
        </div>

        {/* Notifications + upcoming events */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className={`${panel} space-y-3`}>
              <div className="flex items-center justify-between">
                <Skeleton className="h-6 w-48" />
                <Skeleton className="h-8 w-20 rounded-full" />
              </div>
              {Array.from({ length: 4 }).map((__, j) => (
                <Skeleton key={j} className="h-[72px] w-full rounded-2xl" />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function DashboardView({
  memberName,
  fullName,
  userId,
  userCode,
  membershipsCount,
  attendedCount,
  missedCount,
  attendanceRecords,
  setActive,
  notifications,
  upcomingEvents,
  pastEventsCount,
  highlightText,
  loading = false,
  failedFeeds = 0,
  lastUpdatedAt = new Date(),
  onRetryFeeds = () => {},
  retryingFeeds = false,
}: DashboardViewProps) {
  const { t, language, locale } = useLanguage();

  // Ticks every second purely for the live clock in the "My Activity" panel
  // below, the same real-time touch the staff portal's own Dashboard uses --
  // everything else in that panel is real fetched data (notifications,
  // attendance, upcoming events), this just proves the panel is genuinely
  // live rather than a static snapshot.
  const [currentTime, setCurrentTime] = useState(new Date());
  const [clockHour12, toggleClockHour12] = useClockFormat();
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDateCard = (dateStr: string): string => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
    } catch {
      return dateStr;
    }
  };

  const parseMessage = (message: string): { staffName: string; title: string; actualMessage: string } => {
    if (!message) return { staffName: '', title: '', actualMessage: '' };

    const parts = message.split(' • ');
    if (parts.length >= 2) {
      const staffName = parts[0];
      const rest = parts.slice(1).join(' • ');

      if (rest.includes(' — ')) {
        const restParts = rest.split(' — ');
        const title = restParts[0];
        const actualMessage = restParts.slice(1).join(' — ');
        return { staffName, title, actualMessage };
      }
      return { staffName, title: rest, actualMessage: '' };
    }
    return { staffName: '', title: message, actualMessage: '' };
  };

  // Show notifications from THIS WEEK only (Sunday to Saturday) - show 4 items
  const thisWeekNotifications = useMemo(() => {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay()); // Sunday
    startOfWeek.setHours(0, 0, 0, 0);
    
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6); // Saturday
    endOfWeek.setHours(23, 59, 59, 999);
    
    return [...notifications]
      .filter(n => {
        const date = new Date(n.created_at);
        return date >= startOfWeek && date <= endOfWeek;
      })
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 4); // ✅ Changed from 5 to 4
  }, [notifications]);

  // The next 4 upcoming events, soonest first.
  const latestEvents = useMemo(() => {
    const time = (e: any) => {
      const n = new Date(e.event_start ?? e.date).getTime();
      return isNaN(n) ? Infinity : n;
    };
    return [...upcomingEvents].sort((a, b) => time(a) - time(b)).slice(0, 4);
  }, [upcomingEvents]);

  // ─── "MY ACTIVITY" LIVE SNAPSHOT -- everything below is real, already
  // fetched data (notifications, attendance, upcoming events), not invented
  // figures, mirroring how the staff Dashboard's own Live Snapshot panel is
  // built entirely from real fetch cycles. ────────────────────────────────
  const unreadCount = useMemo(() => notifications.filter((n) => !n.read).length, [notifications]);

  const nextEvent = useMemo(() => {
    const sorted = [...upcomingEvents]
      .filter((e) => !isNaN(new Date(e.date).getTime()))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return sorted[0] ?? null;
  }, [upcomingEvents]);

  const daysUntilNextEvent = useMemo(() => {
    if (!nextEvent) return null;
    const diffMs = new Date(nextEvent.date).getTime() - currentTime.getTime();
    return Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
  }, [nextEvent, currentTime]);

  const lastCheckIn = useMemo(() => {
    const completed = [...attendanceRecords]
      .filter((r) => r.status === "complete" && r.eventDate)
      .sort((a, b) => new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime());
    return completed[0] ?? null;
  }, [attendanceRecords]);

  // Same QR payload QRCodesView builds (user_id, user_code, name) -- this is
  // a live preview of that same code, not a separate/fake one.
  const qrData = useMemo(() => {
    if (!userId || !userCode || !fullName) return null;
    // user_id is deliberately NOT in the QR; the scanner resolves by user_code.
    return JSON.stringify({ user_code: userCode, name: fullName });
  }, [userId, userCode, fullName]);

  if (loading) return <MemberDashboardSkeleton memberName={memberName} />;

  return (
    <>
      {/* Full-bleed dark page wrapper -- same convention as every converted
          staff page (Dashboard, Residents, Households, Memberships, Events,
          Inventory, Budget, Returns, Activity Logs, Archive, Reports). */}
      <div className="h-[calc(100dvh-73px)] overflow-y-auto bg-[#0A0E1A] p-4 sm:p-8">
        <div className="space-y-5">
      <MemberDashboardHeader memberName={memberName} />

      <FeedWarning failedCount={failedFeeds} lastOkAt={lastUpdatedAt} onRetry={onRetryFeeds} retrying={retryingFeeds} />

      <div className="report-stagger grid grid-cols-1 gap-4 md:grid-cols-3">
        <SummaryCard
          value={membershipsCount}
          title={t("verifiedMemberships")}
          gradient="from-gold-400 to-gold-700"
          description={t("membershipsDesc")}
          icon={Award}
          onClick={() => setActive("qr")}
        />
        <SummaryCard
          value={attendedCount}
          title={t("eventsAttended")}
          gradient="from-sage-400 to-sage-700"
          description={t("eventsAttendedDesc")}
          icon={CheckCircle2}
          onClick={() => setActive("attendance")}
        />
        <SummaryCard
          value={upcomingEvents.length}
          title={t("upcomingEvents")}
          gradient="from-sage-800 to-[#1C2E2B]"
          description={t("upcomingEventsDesc")}
          icon={CalendarDays}
          onClick={() => setActive("events")}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        {/* My Activity -- genuinely live: a ticking clock plus counts
            derived from data this page already fetches (notifications,
            attendance, upcoming events), same pattern as the staff
            Dashboard's own Live Snapshot panel. */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-colors duration-300 hover:bg-white/[0.06]">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-xl font-bold text-white">{t("myActivityTitle")}</h2>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-[#4FBEB0]/10 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-[#7DD8CB]">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#4FBEB0] opacity-75"></span>
                    <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#4FBEB0]"></span>
                  </span>
                  {t("liveLabel")}
                </span>
              </div>
              <p className="mt-1 text-[15px] text-white/50">
                {currentTime.toLocaleDateString(locale, { weekday: 'long', month: 'long', day: 'numeric' })}
              </p>
            </div>
            <button
              type="button"
              onClick={toggleClockHour12}
              title={clockHour12 ? "24-hour" : "12-hour"}
              aria-label={clockHour12 ? "Switch to 24-hour clock" : "Switch to 12-hour clock"}
              className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2 cursor-pointer select-none transition hover:bg-white/[0.08] hover:border-[#4FBEB0]/40 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#4FBEB0]/50"

            >
              <Clock className="h-4 w-4 text-[#4FBEB0]" />
              <span className="font-display text-lg font-bold tabular-nums text-white">
                {currentTime.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: clockHour12 })}
              </span>
            </button>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3.5">
            {[
              { label: t("unreadNotificationsTile"), value: unreadCount, icon: BellIcon, tone: unreadCount > 0 ? "text-gold-300" : "text-[#4FBEB0]" },
              { label: t("nextEventInTile"), value: daysUntilNextEvent !== null ? `${daysUntilNextEvent}d` : "—", icon: CalendarDays, tone: "text-gold-400" },
              { label: t("lastCheckInTile"), value: lastCheckIn ? formatDateCard(lastCheckIn.eventDate) : "—", icon: ClipboardCheck, tone: "text-[#7DD8CB]" },
              { label: t("missedCheckInsTile"), value: missedCount, icon: AlertCircle, tone: missedCount > 0 ? "text-gold-300" : "text-[#4FBEB0]" },
            ].map((tile) => (
              <div key={tile.label} className="min-w-0 rounded-xl border border-white/10 bg-white/[0.03] p-3 min-[420px]:p-4">
                <div className="flex items-center justify-between gap-2">
                  <span className="min-w-0 truncate font-display text-lg font-extrabold tabular-nums text-white min-[420px]:text-2xl">{tile.value}</span>
                  <tile.icon className={`h-4 w-4 shrink-0 ${tile.tone}`} />
                </div>
                <p className="mt-1.5 text-[11px] font-semibold uppercase tracking-wide text-white/45">{tile.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* My QR Code -- a live preview of the same code shown on the full
            QR page, so residents can glance at it without leaving the
            Dashboard; mirrors the staff Dashboard's own System QR Code
            card. */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-colors duration-300 hover:bg-white/[0.06]">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#4FBEB0]/10">
              <QrCode className="h-5 w-5 text-[#4FBEB0]" />
            </span>
            <h2 className="font-display text-xl font-bold text-white">{t("qr")}</h2>
          </div>
          <p className="mt-3 text-[15px] text-white/50">
            {t("qrPageSubtitle")}
          </p>

          {/* Side-by-side, same layout as the staff Dashboard's own System
              QR Code panel -- code fixed on one side, details + action next
              to it, instead of one big centered stack with a lot of empty
              space around it. */}
          <div className="mt-5 flex flex-col items-start gap-4 sm:flex-row">
            <div className="flex w-full shrink-0 justify-center rounded-xl border-2 border-dashed border-white/15 bg-white/[0.03] p-3 sm:w-auto">
              {qrData ? (
                <QRCodeCanvas value={qrData} size={140} bgColor="#ffffff" fgColor="#0A0E1A" level="H" includeMargin />
              ) : (
                <div className="flex h-[140px] w-[140px] items-center justify-center text-white/30">
                  <QrCode className="h-8 w-8" />
                </div>
              )}
            </div>
            <div className="flex-1">
              <p className="font-medium text-white">{fullName}</p>
              <p className="mt-1 text-sm text-white/50">{t("showQrToStaffCaption")}</p>
              <button
                onClick={() => setActive("qr")}
                className="group mt-3 inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.04] pl-5 pr-1.5 py-1.5 text-[15px] font-semibold text-white shadow-sm transition-all duration-500 ease-out hover:border-[#1E3A5F] hover:bg-[#1E3A5F] hover:shadow-md"
              >
                {t("viewFullQrCode")}
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#0A0E1A] transition-colors duration-500 ease-out group-hover:bg-white/15">
                  <QrCode className="h-4 w-4 text-white" />
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* This Week's Notifications Card */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-colors duration-300 hover:bg-white/[0.06] flex flex-col h-full">
          <div className="flex items-center justify-between flex-shrink-0">
            <div>
              <h2 className="font-display text-xl font-bold text-white">{t("thisWeekNotifications")}</h2>
              <p className="mt-1 text-white/50">{t("thisWeekNotificationsDesc")}</p>
            </div>
            <button
              onClick={() => setActive("notify")}
              className="-mr-2 inline-flex min-h-10 items-center px-2 text-sm text-[#7DD8CB] hover:underline font-semibold transition-colors flex-shrink-0"
            >
              {t("viewAll")}
            </button>
          </div>

          <div
            className="mt-5 space-y-3 overflow-y-auto pr-2 smooth-scroll flex-1"
            style={{ maxHeight: "220px" }}
          >
            {thisWeekNotifications.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] p-10 text-center text-white/40">
                <svg className="w-12 h-12 mx-auto mb-3 text-white/20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <p className="text-base">{t("noNotificationsThisWeek")}</p>
                <p className="text-sm mt-1">{t("checkBackLater")}</p>
              </div>
            ) : (
              thisWeekNotifications.map((item) => {
                const { staffName, title, actualMessage } = parseMessage(item.message);

                return (
                  <div
                    key={item.id}
                    onClick={() => setActive("notify")}
                    className={`cursor-pointer relative rounded-2xl sm:rounded-3xl px-5 sm:px-6 py-4 sm:py-5 border-l-4 transition-all duration-250 ease-out hover:shadow-[0_16px_28px_-8px_rgba(0,0,0,0.35)] hover:-translate-y-1 ${
                      !item.read
                        ? 'border-l-gold-400 bg-gold-400/10 hover:bg-gold-400/[0.15]'
                        : 'border-l-white/15 bg-white/[0.04] hover:bg-white/[0.06]'
                    } border-y border-r border-white/10`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 w-full">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2 text-xs sm:text-sm">
                          {staffName && (
                            <>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className={`text-white/60 break-words text-xs sm:text-sm ${!item.read ? 'font-medium' : ''}`}>
                                  {staffName}
                                </span>
                              </div>
                              <span className="text-white/30 hidden sm:block">•</span>
                            </>
                          )}
                          <div className="flex-1 mt-1.5 sm:mt-0">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className={`font-semibold text-xs sm:text-sm ${
                                !item.read ? 'text-white font-bold' : 'text-white/80'
                              }`}>
                                {title}
                              </span>
                              {actualMessage && (
                                <>
                                  <span className="text-white/30">—</span>
                                  <span className={`text-white/50 break-words text-xs sm:text-sm ${
                                    !item.read ? 'font-medium' : ''
                                  }`}>
                                    {actualMessage}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={`shrink-0 text-xs whitespace-nowrap ${
                        !item.read ? 'font-bold text-white/70' : 'text-white/40'
                      }`}>
                        {formatDateCard(item.created_at)}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Upcoming Events Card */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-colors duration-300 hover:bg-white/[0.06] flex flex-col h-full">
          <div className="flex items-center justify-between flex-shrink-0">
            <div>
              <h2 className="font-display text-xl font-bold text-white">{t("upcomingEvents")}</h2>
              <p className="mt-1 text-white/50">{t("upcomingEventsDesc")}</p>
            </div>
            <button
              onClick={() => setActive("events")}
              className="-mr-2 inline-flex min-h-10 items-center px-2 text-sm text-[#7DD8CB] hover:underline font-semibold transition-colors flex-shrink-0"
            >
              {t("viewAll")}
            </button>
          </div>

          <div
            className="mt-5 space-y-3 overflow-y-auto pr-2 smooth-scroll flex-1"
            style={{ maxHeight: "220px" }}
          >
            {latestEvents.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] p-10 text-center text-white/40">
                <svg className="w-12 h-12 mx-auto mb-3 text-white/20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="text-base">{t("noUpcomingEvents")}</p>
                <p className="text-sm mt-1">{t("checkBackLater")}</p>
              </div>
            ) : (
              latestEvents.map((e) => (
                <div
                  key={e.id}
                  onClick={() => setActive("events")}
                  className="cursor-pointer rounded-xl border-l-4 border-gold-400 bg-white/[0.04] border border-white/10 p-4 transition-all duration-200 hover:bg-white/[0.07] hover:-translate-y-[1px]"
                >
                  <h3 className="text-base font-bold text-white line-clamp-1">{tc(e.title, language as any)}</h3>
                  <p className="mt-1 text-xs text-white/40">{e.date} · {tc(e.location, language as any)}</p>
                  <p className="mt-2 text-sm text-white/60 line-clamp-2">{tc(e.description, language as any)}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
        </div>
      </div>

      <style>{`
        .smooth-scroll {
          scroll-behavior: smooth !important;
          -webkit-overflow-scrolling: touch;
        }
        .smooth-scroll::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        .smooth-scroll::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 10px;
        }
        .smooth-scroll::-webkit-scrollbar-thumb {
          background: #ccc;
          border-radius: 10px;
        }
        .smooth-scroll::-webkit-scrollbar-thumb:hover {
          background: #aaa;
        }
        .line-clamp-1 {
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </>
  );
}